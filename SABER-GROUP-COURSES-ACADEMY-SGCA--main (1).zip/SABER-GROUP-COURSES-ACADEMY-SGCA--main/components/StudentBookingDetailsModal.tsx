import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Booking, Customer, InstallmentPlan, Payment, BookingLog, UserProfile, Group, Course, Diploma } from '../types';
import { getBookingLogs, genericGet, genericGetQuery, rollbackBookingAction } from '../services/firestore';
import { where } from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

interface StudentBookingDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: Booking | null;
  customer: Customer | null;
  plan?: InstallmentPlan;
  onPay?: (bookingId: string, amount: number) => void;
  onReschedule?: (bookingId: string, booking: Booking) => void;
  onDataChanged?: () => void;
}

const StudentBookingDetailsModal: React.FC<StudentBookingDetailsModalProps> = ({
  isOpen,
  onClose,
  booking,
  customer,
  plan,
  onPay,
  onReschedule,
  onDataChanged
}) => {
  const { isRtl, lang } = useTheme();
  const { effectiveProfile, hasPermission } = useAuth();
  const userProfile = effectiveProfile;
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState<'overview' | 'student' | 'booking' | 'history' | 'agreements'>('overview');
  const [logs, setLogs] = useState<BookingLog[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [group, setGroup] = useState<Group | null>(null);
  const [productDetails, setProductDetails] = useState<Course | Diploma | null>(null);
  const [userMap, setUserMap] = useState<Record<string, string>>({});
  
  const [loading, setLoading] = useState(false);
  const [reversingId, setReversingId] = useState<string | null>(null);
  const [confirmReversal, setConfirmReversal] = useState<BookingLog | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && booking) {
      setActiveTab('overview');
      fetchDetails();
      fetchUsers();
      setSuccessMessage(null);
      setErrorMessage(null);
    }
  }, [isOpen, booking?.id]);

  const copyToClipboard = (text: string, fieldName: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const fetchUsers = async () => {
    try {
      const users = await genericGet<UserProfile>('users');
      const map: Record<string, string> = {};
      users.forEach(u => {
        if (u.uid && u.displayName) {
          map[u.uid] = u.displayName;
        }
      });
      setUserMap(map);
    } catch (err) {
      console.error("Error fetching users for log resolution:", err);
    }
  };

  const fetchDetails = async () => {
    if (!booking) return;
    setLoading(true);
    try {
      // 1. Fetch Logs
      const logsPromise = getBookingLogs(booking.id);
      
      // 2. Fetch Payments for this booking
      const paymentsPromise = genericGetQuery<Payment>('payments', [where('bookingId', '==', booking.id)]);

      // 3. Fetch Group if assigned
      let groupPromise: Promise<Group[]> = Promise.resolve([]);
      if (booking.groupId) {
        groupPromise = genericGetQuery<Group>('groups', [where('id', '==', booking.groupId)]);
      }

      // 4. Fetch Course / Diploma info
      let productPromise: Promise<any[]> = Promise.resolve([]);
      if (booking.productId) {
        const coll = booking.productType === 'diploma' ? 'catalog_diplomas' : booking.productType === 'workshop' ? 'catalog_workshops' : 'catalog_courses';
        productPromise = genericGetQuery<any>(coll, [where('id', '==', booking.productId)]);
      }

      const [fetchedLogs, fetchedPayments, fetchedGroups, fetchedProducts] = await Promise.all([
        logsPromise,
        paymentsPromise,
        groupPromise,
        productPromise
      ]);

      setLogs(fetchedLogs);
      setPayments(fetchedPayments.filter(p => !p.isDeleted));
      if (fetchedGroups.length > 0) setGroup(fetchedGroups[0]);
      if (fetchedProducts.length > 0) setProductDetails(fetchedProducts[0]);
    } catch (err) {
      console.error("Error fetching details for student booking modal:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleRollback = async (log: BookingLog) => {
    if (!booking) return;
    setReversingId(log.id);
    setErrorMessage(null);
    try {
      const performer = { 
        name: userProfile?.displayName || 'Unknown', 
        email: userProfile?.email || '' 
      };
      
      await rollbackBookingAction(booking.id, log.id, performer);
      
      setSuccessMessage(`تم التراجع عن حركة (${getActionLabel(log.action)}) بنجاح واستعادة حالة العميل.`);
      setConfirmReversal(null);
      await fetchDetails();
      if (onDataChanged) {
        onDataChanged();
      }
      setTimeout(() => {
        setSuccessMessage(null);
      }, 5000);
    } catch (err: any) {
      console.error("Error during rollback:", err);
      setErrorMessage(`تعذر التراجع: ${err.message || 'حدث خطأ غير متوقع'}`);
    } finally {
      setReversingId(null);
    }
  };

  if (!isOpen || !booking) return null;

  const rawPhone = customer?.whatsapp || customer?.phone || '';
  const cleanDigits = rawPhone.replace(/\D/g, '');
  let formattedWaPhone = cleanDigits;
  if (cleanDigits.startsWith('01')) {
    formattedWaPhone = '20' + cleanDigits.substring(1);
  } else if (!cleanDigits.startsWith('20') && cleanDigits.length === 10 && cleanDigits.startsWith('1')) {
    formattedWaPhone = '20' + cleanDigits;
  }
  const courseName = (booking as any).productName || (booking as any).courseName || productDetails?.name || 'الكورس';
  const remainingAmount = booking.paymentSummary?.remaining ?? 0;
  const paidTotal = booking.paymentSummary?.paidTotal ?? 0;
  const finalPrice = booking.pricing?.finalPriceSnapshot ?? (paidTotal + remainingAmount);
  const basePrice = booking.pricing?.basePriceSnapshot ?? finalPrice;
  const savings = booking.pricing?.savingsSnapshot ?? (basePrice > finalPrice ? basePrice - finalPrice : 0);
  const extraDiscount = booking.pricing?.extraDiscountSnapshot ?? 0;

  const waMsg = `أهلاً بك يا ${customer?.name || ''}، بخصوص كورس ${courseName}، نود التنسيق معك بخصوص الحجز والمتبقي (${remainingAmount.toLocaleString()} ج.م).`;
  const waUrl = formattedWaPhone ? `https://wa.me/${formattedWaPhone}?text=${encodeURIComponent(waMsg)}` : '';

  const resolvePerformer = (performer: string | undefined) => {
    if (!performer) return 'النظام (System)';
    if (userMap[performer]) return userMap[performer];
    return performer;
  };

  const getActionLabel = (action: string) => {
    switch (action) {
      case 'CREATED': return 'إنشاء الحجز الأول';
      case 'PAYMENT': return 'استلام دفعة / قسط';
      case 'COMPLETION_PAYMENT': return 'دفعة استكمال البداية';
      case 'REFUNDED': return 'استرداد / خصم مالي';
      case 'UPDATED': return 'تعديل بيانات الحجز / العميل';
      case 'ASSIGNED':
      case 'GROUP_ASSIGNED': return 'تسكين / تغيير المجموعة';
      case 'RESCHEDULED': return 'إعادة جدولة الأقساط';
      case 'PLAN_UPDATED': return 'تعديل خطة الأقساط';
      case 'DEACTIVATED': return 'إلغاء تفعيل الحجز';
      case 'RESTORED': return 'استعادة الحجز الملغي';
      case 'PAYMENT_REVERSED': return 'إلغاء دفعة سابقة';
      case 'REFUND_REVERSED': return 'إلغاء استرداد سابق';
      case 'ACTION_REVERSED': return 'تراجع عن حركة سابقة';
      default: return action;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'CREATED': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 border-emerald-200';
      case 'PAYMENT':
      case 'COMPLETION_PAYMENT': return 'bg-blue-100 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300 border-blue-200';
      case 'REFUNDED': return 'bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300 border-rose-200';
      case 'UPDATED': return 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 border-amber-200';
      case 'ASSIGNED':
      case 'GROUP_ASSIGNED': return 'bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300 border-purple-200';
      case 'RESCHEDULED': return 'bg-cyan-100 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300 border-cyan-200';
      case 'DEACTIVATED': return 'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-300 border-red-200';
      case 'RESTORED': return 'bg-teal-100 text-teal-700 dark:bg-teal-950/40 dark:text-teal-300 border-teal-200';
      case 'ACTION_REVERSED':
      case 'PAYMENT_REVERSED':
      case 'REFUND_REVERSED': return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300 border-gray-300';
      default: return 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300 border-indigo-200';
    }
  };

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATED': return 'fa-plus-circle';
      case 'PAYMENT':
      case 'COMPLETION_PAYMENT': return 'fa-money-bill-wave';
      case 'REFUNDED': return 'fa-undo';
      case 'UPDATED': return 'fa-edit';
      case 'ASSIGNED':
      case 'GROUP_ASSIGNED': return 'fa-users';
      case 'RESCHEDULED': return 'fa-calendar-alt';
      case 'PLAN_UPDATED': return 'fa-tasks';
      case 'DEACTIVATED': return 'fa-ban';
      case 'RESTORED': return 'fa-check-circle';
      case 'ACTION_REVERSED':
      case 'PAYMENT_REVERSED':
      case 'REFUND_REVERSED': return 'fa-history';
      default: return 'fa-info-circle';
    }
  };

  const isRollbackable = (log: BookingLog) => {
    if (log.details?.isReversed) return false;
    if (log.action === 'ACTION_REVERSED' || log.action === 'PAYMENT_REVERSED' || log.action === 'REFUND_REVERSED') return false;
    return hasPermission('reverseActions') || userProfile?.role === 'admin' || userProfile?.role === 'supervisor' || userProfile?.role === 'manager';
  };

  const agreement = booking.unscheduledAgreement;
  const agreementNotesHistory = agreement?.notesHistory || [];

  const handlePrintSummary = () => {
    const w = window.open('', '_blank');
    if (!w) return;

    const html = `
      <html dir="rtl">
        <head>
          <title>بيانات وسجل الطالب - ${customer?.name || 'Student'}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; color: #1f2937; line-height: 1.6; direction: rtl; }
            .header { border-bottom: 3px solid #4f46e5; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center; }
            .title { font-size: 24px; font-weight: bold; color: #4f46e5; }
            .section { margin-bottom: 25px; background: #f9fafb; padding: 20px; border-radius: 12px; border: 1px solid #e5e7eb; }
            .section-title { font-size: 16px; font-weight: 800; color: #111827; margin-bottom: 12px; border-bottom: 1px solid #e5e7eb; padding-bottom: 6px; }
            .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
            .item { font-size: 13px; }
            .label { font-weight: bold; color: #6b7280; font-size: 11px; text-transform: uppercase; }
            .value { font-weight: 600; color: #111827; }
            .highlight { color: #4f46e5; font-weight: 800; }
            .log-item { border-bottom: 1px solid #e5e7eb; padding: 12px 0; font-size: 12px; }
            @media print { body { padding: 20px; } .no-print { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <div class="title">بيانات الحجز وسجل الطالب الكامل</div>
              <div style="font-size: 12px; color: #6b7280; margin-top: 5px;">تاريخ الطباعة: ${new Date().toLocaleString('ar-EG')}</div>
            </div>
            <div style="font-size: 18px; font-weight: bold; color: #374151;">SG ACADEMY</div>
          </div>

          <div class="section">
            <div class="section-title">بيانات الطالب الشخصية</div>
            <div class="grid">
              <div class="item"><div class="label">اسم الطالب</div><div class="value">${customer?.name || '-'}</div></div>
              <div class="item"><div class="label">رقم الهاتف / واتساب</div><div class="value" dir="ltr">${customer?.whatsapp || customer?.phone || '-'}</div></div>
              <div class="item"><div class="label">البريد الإلكتروني</div><div class="value">${customer?.email || '-'}</div></div>
              <div class="item"><div class="label">رقم الحجز (Booking ID)</div><div class="value" dir="ltr">${booking.id}</div></div>
            </div>
          </div>

          <div class="section">
            <div class="section-title">بيانات الحجز والماليات</div>
            <div class="grid">
              <div class="item"><div class="label">الكورس / البرنامج</div><div class="value highlight">${courseName}</div></div>
              <div class="item"><div class="label">تاريخ الحجز</div><div class="value">${booking.bookingDate || '-'}</div></div>
              <div class="item"><div class="label">مسؤول المبيعات (Sales)</div><div class="value">${booking.salesName || '-'}</div></div>
              <div class="item"><div class="label">حالة الحجز</div><div class="value">${booking.status}</div></div>
              <div class="item"><div class="label">السعر الإجمالي</div><div class="value">${finalPrice.toLocaleString()} ج.م</div></div>
              <div class="item"><div class="label">المدفوع الفعلي</div><div class="value" style="color: #10b981;">${paidTotal.toLocaleString()} ج.م</div></div>
              <div class="item"><div class="label">المبلغ المتبقي</div><div class="value" style="color: #ef4444; font-size: 16px; font-weight: 800;">${remainingAmount.toLocaleString()} ج.م</div></div>
            </div>
          </div>

          ${agreement?.agreementNote ? `
          <div class="section">
            <div class="section-title">اتفاق ومتابعة السيلز للمتبقي</div>
            <div style="font-size: 13px; font-weight: 600; margin-bottom: 8px;">${agreement.agreementNote}</div>
            <div class="grid">
              <div class="item"><div class="label">الموعد المتفق عليه</div><div class="value">${agreement.agreedDate || '-'}</div></div>
              <div class="item"><div class="label">عدد الأقساط المقترحة</div><div class="value">${agreement.suggestedCount || 1}</div></div>
              <div class="item"><div class="label">مسجل الاتفاق</div><div class="value">${agreement.updatedByName || '-'}</div></div>
            </div>
          </div>
          ` : ''}

          <div class="section">
            <div class="section-title">سجل الحركات والتعديلات (${logs.length})</div>
            ${logs.map(log => `
              <div class="log-item">
                <div style="display: flex; justify-content: space-between; font-weight: bold;">
                  <span>${getActionLabel(log.action)}</span>
                  <span style="color: #6b7280; font-size: 11px;" dir="ltr">${new Date(log.timestamp).toLocaleString('ar-EG')}</span>
                </div>
                <div style="margin: 4px 0;">${log.description}</div>
                <div style="color: #9ca3af; font-size: 11px;">بواسطة: ${resolvePerformer(log.performedBy)}</div>
              </div>
            `).join('')}
          </div>

          <div style="margin-top: 50px; text-align: center; font-size: 11px; color: #9ca3af; border-top: 1px solid #e5e7eb; padding-top: 20px;">
            نظام إدارة الحجوزات والحسابات - SG ACADEMY
          </div>
        </body>
      </html>
    `;

    w.document.write(html);
    w.document.close();
    w.onload = () => {
      w.print();
      w.close();
    };
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-3 md:p-6 overflow-y-auto" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="bg-white dark:bg-gray-800 rounded-[2.5rem] shadow-2xl w-full max-w-5xl max-h-[92vh] flex flex-col relative border border-gray-100 dark:border-gray-700 overflow-hidden animate-in fade-in-50">
        
        {/* Rollback Confirmation Overlay */}
        {confirmReversal && (
          <div className="absolute inset-0 z-[110] bg-white/95 dark:bg-gray-800/95 backdrop-blur-md flex items-center justify-center p-6 rounded-[2.5rem]">
            <div className="max-w-lg text-center w-full">
              <div className="w-16 h-16 bg-amber-100 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl animate-pulse">
                <i className="fas fa-history"></i>
              </div>
              <h3 className="text-xl font-black text-gray-800 dark:text-white mb-2">
                تأكيد التراجع عن الحركة
              </h3>
              <p className="text-xs text-gray-600 dark:text-gray-300 font-medium mb-5 leading-relaxed">
                هل تريد بالتأكيد التراجع عن حركة ({getActionLabel(confirmReversal.action)}) واستعادة الحالة السابقة؟
              </p>

              <div className="flex justify-center gap-3">
                <button
                  onClick={() => setConfirmReversal(null)}
                  disabled={!!reversingId}
                  className="px-6 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-gray-700 dark:text-gray-200 rounded-xl text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  onClick={() => handleRollback(confirmReversal)}
                  disabled={!!reversingId}
                  className="px-8 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-black shadow-lg shadow-amber-600/30 flex items-center gap-2"
                >
                  {reversingId ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-undo"></i>}
                  <span>تأكيد التراجع الآن</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal Header */}
        <div className="p-6 pb-4 border-b dark:border-gray-700/80 bg-gray-50/50 dark:bg-gray-900/30">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center text-xl font-black shadow-lg shadow-indigo-600/20">
                <i className="fas fa-user-graduate"></i>
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <h2 className="text-xl font-black text-gray-900 dark:text-white">
                    {customer?.name || 'تفاصيل الطالب والحجز'}
                  </h2>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    booking.status === 'ACTIVE' ? 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300' : 'bg-red-100 text-red-700'
                  }`}>
                    {booking.status}
                  </span>
                  {remainingAmount > 0 && (!plan || !plan.installments || plan.installments.filter(i => i.status === 'pending' || i.status === 'delayed').length === 0) && (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 flex items-center gap-1">
                      <i className="fas fa-calendar-times text-[9px]"></i>
                      <span>متبقي غير مجدول</span>
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500 dark:text-gray-400">
                  <span className="font-bold text-indigo-600 dark:text-indigo-400">{courseName}</span>
                  <span>•</span>
                  <span>تاريخ الحجز: <strong className="text-gray-700 dark:text-gray-300">{booking.bookingDate}</strong></span>
                  <span>•</span>
                  <span>مسؤول المبيعات: <strong className="text-gray-700 dark:text-gray-300">{booking.salesName || 'Unknown'}</strong></span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrintSummary}
                className="p-2.5 text-gray-500 hover:text-gray-700 dark:hover:text-gray-200 bg-white dark:bg-gray-700 rounded-xl border dark:border-gray-600 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
                title="طباعة تقرير الطالب"
              >
                <i className="fas fa-print"></i>
                <span className="hidden sm:inline">طباعة</span>
              </button>

              {customer?.id && (
                <button
                  onClick={() => {
                    onClose();
                    navigate(`/students?id=${customer.id}`);
                  }}
                  className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 rounded-xl border border-indigo-200 dark:border-indigo-800 text-xs font-black flex items-center gap-1.5 transition-all"
                  title="فتح البروفايل الكامل في شاشة بحث الطلاب"
                >
                  <i className="fas fa-external-link-alt text-[10px]"></i>
                  <span className="hidden sm:inline">بروفايل الطالب</span>
                </button>
              )}

              <button
                onClick={onClose}
                className="w-10 h-10 rounded-2xl bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-500 dark:text-gray-300 flex items-center justify-center transition-all"
              >
                <i className="fas fa-times text-base"></i>
              </button>
            </div>
          </div>

          {/* Quick Tabs Navigation */}
          <div className="flex flex-wrap gap-2 mt-5 border-t dark:border-gray-700/60 pt-3">
            {[
              { id: 'overview' as const, label: 'ملخص شامل', icon: 'fa-chart-pie' },
              { id: 'student' as const, label: 'بيانات الطالب', icon: 'fa-id-card' },
              { id: 'booking' as const, label: 'بيانات الحجز والماليات', icon: 'fa-file-invoice-dollar', badge: payments.length > 0 ? `${payments.length} دفعات` : undefined },
              { id: 'history' as const, label: 'سجل الحركات والتعديلات (History)', icon: 'fa-history', badge: logs.length > 0 ? `${logs.length}` : undefined },
              { id: 'agreements' as const, label: 'متابعة واتفاقات السيلز', icon: 'fa-comments', badge: agreementNotesHistory.length > 0 ? `${agreementNotesHistory.length}` : undefined }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                    : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700/60 border border-gray-200/60 dark:border-gray-700'
                }`}
              >
                <i className={`fas ${tab.icon} text-[11px]`}></i>
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                    activeTab === tab.id ? 'bg-white/20 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Modal Body Container */}
        <div className="p-6 overflow-y-auto flex-1 custom-scrollbar space-y-6">
          
          {successMessage && (
            <div className="p-3.5 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-2.5 text-emerald-800 dark:text-emerald-200 text-xs font-bold animate-in fade-in">
              <i className="fas fa-check-circle text-emerald-500"></i>
              <span>{successMessage}</span>
            </div>
          )}

          {errorMessage && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-2xl flex items-center gap-2.5 text-rose-800 dark:text-rose-200 text-xs font-bold animate-in fade-in">
              <i className="fas fa-exclamation-triangle text-rose-500"></i>
              <span>{errorMessage}</span>
            </div>
          )}

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              
              {/* Financial Progress & KPI Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-gray-50 dark:bg-gray-700/40 p-4 rounded-2xl border dark:border-gray-700">
                  <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-1">السعر الإجمالي النهائي</span>
                  <div className="text-2xl font-black text-gray-900 dark:text-white">
                    {finalPrice.toLocaleString()} <span className="text-xs">ج.م</span>
                  </div>
                  {savings > 0 && (
                    <span className="text-[10px] text-green-600 dark:text-green-400 font-bold block mt-0.5">
                      وفر {savings.toLocaleString()} ج.م من السعر الأساسي
                    </span>
                  )}
                </div>

                <div className="bg-emerald-50/50 dark:bg-emerald-950/20 p-4 rounded-2xl border border-emerald-100 dark:border-emerald-900/40">
                  <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest block mb-1">إجمالي المدفوع</span>
                  <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400">
                    {paidTotal.toLocaleString()} <span className="text-xs">ج.م</span>
                  </div>
                  <span className="text-[10px] text-emerald-700 dark:text-emerald-300 font-bold block mt-0.5">
                    {Math.round((paidTotal / (finalPrice || 1)) * 100)}% من إجمالي الحجز
                  </span>
                </div>

                <div className="bg-rose-50/50 dark:bg-rose-950/20 p-4 rounded-2xl border border-rose-100 dark:border-rose-900/40">
                  <span className="text-[10px] font-black text-rose-600 dark:text-rose-400 uppercase tracking-widest block mb-1">المبلغ المتبقي المستحق</span>
                  <div className="text-2xl font-black text-rose-600 dark:text-rose-400">
                    {remainingAmount.toLocaleString()} <span className="text-xs">ج.م</span>
                  </div>
                  <span className="text-[10px] text-rose-700 dark:text-rose-300 font-bold block mt-0.5">
                    {remainingAmount === 0 ? 'خالص السداد بالكامل ✅' : 'مستحق السداد'}
                  </span>
                </div>

                <div className="bg-indigo-50/50 dark:bg-indigo-950/20 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-900/40">
                  <span className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest block mb-1">حالة الجدولة والأقساط</span>
                  <div className="text-base font-black text-indigo-900 dark:text-indigo-200 mt-1">
                    {plan && plan.installments && plan.installments.filter(i => i.status === 'pending' || i.status === 'delayed').length > 0 ? (
                      <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                        <i className="fas fa-check-circle"></i>
                        <span>مجدول ({plan.installments.filter(i => i.status === 'pending' || i.status === 'delayed').length} أقساط)</span>
                      </span>
                    ) : remainingAmount > 0 ? (
                      <span className="flex items-center gap-1 text-amber-600 dark:text-amber-400">
                        <i className="fas fa-calendar-times"></i>
                        <span>غير مجدول</span>
                      </span>
                    ) : (
                      <span className="text-gray-500">لا توجد أقساط</span>
                    )}
                  </div>
                  {agreement?.agreedDate && (
                    <span className="text-[10px] text-indigo-600 font-bold block mt-0.5">
                      موعد الاتفاق: {agreement.agreedDate}
                    </span>
                  )}
                </div>
              </div>

              {/* Two Column Section: Quick Student Data & Booking Overview */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                
                {/* Student Quick Card */}
                <div className="p-5 bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b dark:border-gray-700">
                    <h3 className="font-black text-sm text-gray-900 dark:text-white flex items-center gap-2">
                      <i className="fas fa-user text-indigo-600"></i>
                      <span>بيانات الطالب الأساسية</span>
                    </h3>
                    <button
                      onClick={() => setActiveTab('student')}
                      className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                    >
                      عرض التفاصيل الكاملة ←
                    </button>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">الاسم الكامل:</span>
                      <span className="font-bold text-gray-900 dark:text-gray-100">{customer?.name || '-'}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">رقم الهاتف:</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-gray-900 dark:text-gray-100" dir="ltr">{customer?.phone || '-'}</span>
                        {customer?.phone && (
                          <button
                            onClick={() => copyToClipboard(customer.phone, 'phone')}
                            className="text-gray-400 hover:text-indigo-600"
                            title="نسخ الرقم"
                          >
                            <i className={`fas ${copiedField === 'phone' ? 'fa-check text-green-500' : 'fa-copy'}`}></i>
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">واتساب:</span>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-emerald-600" dir="ltr">{customer?.whatsapp || '-'}</span>
                        {waUrl && (
                          <a
                            href={waUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-600 hover:text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded-lg text-[10px] font-bold flex items-center gap-1"
                          >
                            <i className="fab fa-whatsapp"></i>
                            <span>محادثة</span>
                          </a>
                        )}
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-500">البريد الإلكتروني:</span>
                      <span className="font-medium text-gray-700 dark:text-gray-300">{customer?.email || 'غير مسجل'}</span>
                    </div>
                  </div>
                </div>

                {/* Booking & Sales Agreement Card */}
                <div className="p-5 bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 shadow-sm space-y-4">
                  <div className="flex justify-between items-center pb-3 border-b dark:border-gray-700">
                    <h3 className="font-black text-sm text-gray-900 dark:text-white flex items-center gap-2">
                      <i className="fas fa-file-contract text-amber-600"></i>
                      <span>اتفاق السيلز ومتابعة المتبقي</span>
                    </h3>
                    {agreementNotesHistory.length > 1 && (
                      <button
                        onClick={() => setActiveTab('agreements')}
                        className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline"
                      >
                        سجل الاتفاقات ({agreementNotesHistory.length}) ←
                      </button>
                    )}
                  </div>

                  {agreement?.agreementNote ? (
                    <div className="space-y-3">
                      <div className="p-3 bg-amber-50/60 dark:bg-amber-950/30 rounded-2xl border border-amber-200/70 dark:border-amber-900/40 text-xs font-semibold text-gray-800 dark:text-gray-200 leading-relaxed whitespace-pre-wrap">
                        {agreement.agreementNote}
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-[11px]">
                        {agreement.agreedDate && (
                          <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-bold px-2.5 py-1 rounded-xl border border-blue-200 dark:border-blue-800">
                            <i className="fas fa-calendar-check mr-1 text-blue-500"></i>
                            الموعد المتفق عليه: {agreement.agreedDate}
                          </span>
                        )}
                        {agreement.suggestedCount && (
                          <span className="bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold px-2.5 py-1 rounded-xl border border-purple-200 dark:border-purple-800">
                            <i className="fas fa-list-ol mr-1 text-purple-500"></i>
                            {agreement.suggestedCount} أقساط مقترحة
                          </span>
                        )}
                        {agreement.updatedByName && (
                          <span className="text-gray-400 text-[10px] mr-auto">
                            بواسطة: {agreement.updatedByName}
                          </span>
                        )}
                      </div>
                    </div>
                  ) : (
                    <div className="p-5 text-center bg-gray-50 dark:bg-gray-700/20 rounded-2xl text-xs text-gray-400">
                      <i className="fas fa-info-circle text-lg mb-1 block text-gray-300"></i>
                      لا يوجد اتفاق سيلز مسجل حتى الآن لهذا الحجز.
                    </div>
                  )}
                </div>

              </div>

              {/* Recent Activity Log Snapshot */}
              <div className="p-5 bg-gray-50 dark:bg-gray-700/30 rounded-3xl border dark:border-gray-700 space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="font-black text-xs uppercase tracking-wider text-gray-600 dark:text-gray-400 flex items-center gap-2">
                    <i className="fas fa-history text-indigo-500"></i>
                    <span>آخر حركات وسجل الحجز ({logs.length} حركات)</span>
                  </h3>
                  <button
                    onClick={() => setActiveTab('history')}
                    className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline"
                  >
                    عرض السجل الكامل والتراجع ←
                  </button>
                </div>

                <div className="space-y-2">
                  {logs.slice(0, 3).map((log, idx) => (
                    <div key={idx} className="p-3 bg-white dark:bg-gray-800 rounded-xl border dark:border-gray-700 flex justify-between items-center gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] ${getActionColor(log.action)}`}>
                          <i className={`fas ${getActionIcon(log.action)}`}></i>
                        </span>
                        <div>
                          <span className="font-bold text-gray-900 dark:text-gray-100">{log.description}</span>
                          <span className="text-[10px] text-gray-400 block">بواسطة: {resolvePerformer(log.performedBy)}</span>
                        </div>
                      </div>
                      <span className="text-[10px] text-gray-400 font-mono" dir="ltr">
                        {new Date(log.timestamp).toLocaleDateString('ar-EG')}
                      </span>
                    </div>
                  ))}
                  {logs.length === 0 && (
                    <p className="text-xs text-gray-400 text-center py-2">لا توجد حركات مسجلة</p>
                  )}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: STUDENT DETAILS */}
          {activeTab === 'student' && (
            <div className="space-y-6">
              <div className="p-6 bg-gray-50 dark:bg-gray-700/30 rounded-3xl border dark:border-gray-700 space-y-6">
                <div className="flex items-center gap-3 pb-4 border-b dark:border-gray-700">
                  <div className="w-12 h-12 rounded-2xl bg-primary-600 text-white flex items-center justify-center text-xl font-black">
                    <i className="fas fa-id-card"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-gray-900 dark:text-white">{customer?.name || 'بيانات الطالب'}</h3>
                    <p className="text-xs text-gray-500">رقم الطالب في النظام: {customer?.id}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl border dark:border-gray-700 space-y-1">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">الاسم الكامل</span>
                    <span className="text-base font-bold text-gray-900 dark:text-white">{customer?.name || '-'}</span>
                  </div>

                  <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl border dark:border-gray-700 space-y-1">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">رقم الهاتف الأساسي</span>
                    <div className="flex items-center justify-between">
                      <span className="text-base font-bold text-gray-900 dark:text-white font-mono" dir="ltr">{customer?.phone || '-'}</span>
                      {customer?.phone && (
                        <div className="flex gap-2">
                          <button onClick={() => copyToClipboard(customer.phone, 'phone_main')} className="text-gray-400 hover:text-indigo-600">
                            <i className={`fas ${copiedField === 'phone_main' ? 'fa-check text-green-500' : 'fa-copy'}`}></i>
                          </button>
                          <a href={`tel:${customer.phone}`} className="text-indigo-600 hover:text-indigo-700">
                            <i className="fas fa-phone-alt"></i>
                          </a>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl border dark:border-gray-700 space-y-1">
                    <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest block">رقم الواتساب</span>
                    <div className="flex items-center justify-between">
                      <span className="text-base font-bold text-emerald-600 font-mono" dir="ltr">{customer?.whatsapp || customer?.fullWhatsapp || '-'}</span>
                      {waUrl && (
                        <a
                          href={waUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-sm"
                        >
                          <i className="fab fa-whatsapp"></i>
                          <span>مراسلة واتساب</span>
                        </a>
                      )}
                    </div>
                  </div>

                  <div className="p-4 bg-white dark:bg-gray-800 rounded-2xl border dark:border-gray-700 space-y-1">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">البريد الإلكتروني</span>
                    <span className="text-sm font-semibold text-gray-800 dark:text-gray-200">{customer?.email || 'غير مسجل'}</span>
                  </div>
                </div>

                {customer?.id && (
                  <div className="pt-2 flex justify-end">
                    <button
                      onClick={() => {
                        onClose();
                        navigate(`/students?id=${customer.id}`);
                      }}
                      className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md shadow-indigo-600/20 flex items-center gap-2 transition-all"
                    >
                      <i className="fas fa-user-circle"></i>
                      <span>فتح ملف الطالب الكامل في شاشة البحث</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: BOOKING & FINANCIAL DETAILS */}
          {activeTab === 'booking' && (
            <div className="space-y-6">
              
              {/* Product & Group Info */}
              <div className="p-5 bg-gray-50 dark:bg-gray-700/30 rounded-3xl border dark:border-gray-700 space-y-4">
                <div className="flex justify-between items-center pb-3 border-b dark:border-gray-700">
                  <h3 className="font-black text-sm text-gray-900 dark:text-white flex items-center gap-2">
                    <i className="fas fa-graduation-cap text-indigo-600"></i>
                    <span>بيانات البرنامج والمجموعة</span>
                  </h3>
                  <span className="text-xs font-bold text-gray-500">رقم الحجز: <code className="text-indigo-600">{booking.id}</code></span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-white dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                    <span className="text-[10px] font-bold text-gray-400 block mb-0.5">اسم الكورس / الدبلومة</span>
                    <span className="font-black text-indigo-600 text-sm">{courseName}</span>
                  </div>

                  <div className="p-3 bg-white dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                    <span className="text-[10px] font-bold text-gray-400 block mb-0.5">نوع الحجز وتاريخه</span>
                    <span className="font-bold text-gray-800 dark:text-gray-200">{booking.bookingType === 'assigned' ? 'مسكن بمجموعة' : 'مؤجل / غير مسكن'} ({booking.bookingDate})</span>
                  </div>

                  <div className="p-3 bg-white dark:bg-gray-800 rounded-xl border dark:border-gray-700">
                    <span className="text-[10px] font-bold text-gray-400 block mb-0.5">المجموعة والتوقيت</span>
                    <span className="font-bold text-gray-800 dark:text-gray-200">
                      {group ? `${group.scheduleLabel || group.groupCode || 'مجموعة'} (${group.daysOfWeek?.join(', ') || ''})` : (booking as any).groupName || 'غير مسكن'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Pricing Breakdown Snapshot */}
              <div className="p-5 bg-white dark:bg-gray-800 rounded-3xl border border-gray-200 dark:border-gray-700 space-y-4">
                <h3 className="font-black text-sm text-gray-900 dark:text-white flex items-center gap-2 pb-2 border-b dark:border-gray-700">
                  <i className="fas fa-calculator text-emerald-600"></i>
                  <span>تفاصيل التسعير والخصومات المعتمدة</span>
                </h3>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-3 bg-gray-50 dark:bg-gray-700/40 rounded-xl">
                    <span className="text-[10px] font-bold text-gray-400 block mb-0.5">السعر الأساسي (Base)</span>
                    <span className="font-bold text-gray-900 dark:text-white">{basePrice.toLocaleString()} ج.م</span>
                  </div>

                  <div className="p-3 bg-gray-50 dark:bg-gray-700/40 rounded-xl">
                    <span className="text-[10px] font-bold text-gray-400 block mb-0.5">الخصم / العرض</span>
                    <span className="font-bold text-green-600">-{savings.toLocaleString()} ج.م</span>
                  </div>

                  <div className="p-3 bg-gray-50 dark:bg-gray-700/40 rounded-xl">
                    <span className="text-[10px] font-bold text-gray-400 block mb-0.5">خصم إضافي</span>
                    <span className="font-bold text-gray-700 dark:text-gray-300">{extraDiscount ? `-${extraDiscount.toLocaleString()} ج.م` : 'لا يوجد'}</span>
                  </div>

                  <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-100 dark:border-indigo-800">
                    <span className="text-[10px] font-black text-indigo-600 uppercase block mb-0.5">السعر النهائي للحجز</span>
                    <span className="font-black text-indigo-700 dark:text-indigo-300 text-sm">{finalPrice.toLocaleString()} ج.م</span>
                  </div>
                </div>
              </div>

              {/* Payments History List */}
              <div className="p-5 bg-gray-50 dark:bg-gray-700/30 rounded-3xl border dark:border-gray-700 space-y-4">
                <div className="flex justify-between items-center pb-2 border-b dark:border-gray-700">
                  <h3 className="font-black text-sm text-gray-900 dark:text-white flex items-center gap-2">
                    <i className="fas fa-receipt text-green-600"></i>
                    <span>سجل المدفوعات المستلمة ({payments.length} دفعات)</span>
                  </h3>
                  <span className="text-xs font-bold text-emerald-600">إجمالي المستلم: {paidTotal.toLocaleString()} ج.م</span>
                </div>

                {payments.length > 0 ? (
                  <div className="space-y-2">
                    {payments.map((p, idx) => (
                      <div key={idx} className="p-3.5 bg-white dark:bg-gray-800 rounded-2xl border dark:border-gray-700 flex flex-wrap items-center justify-between gap-3 text-xs">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center justify-center font-bold">
                            #{idx + 1}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="font-black text-emerald-600 text-sm">{p.amount.toLocaleString()} ج.م</span>
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-gray-100 dark:bg-gray-700 rounded-md uppercase">
                                {p.method}
                              </span>
                            </div>
                            <p className="text-[10px] text-gray-400 mt-0.5">
                              التاريخ: <strong className="text-gray-600 dark:text-gray-300">{p.paymentDate}</strong>
                              {p.referenceNumber && ` | مرجع: ${p.referenceNumber}`}
                              {p.performedBy?.name && ` | المستلم: ${p.performedBy.name}`}
                            </p>
                          </div>
                        </div>

                        {p.receiptLink && (
                          <a
                            href={p.receiptLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-1"
                          >
                            <i className="fas fa-file-image"></i>
                            <span>عرض الإيصال</span>
                          </a>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-gray-400 bg-white dark:bg-gray-800 rounded-2xl text-xs">
                    لم يتم تسجيل أي دفعات مالية بعد لهذا الحجز.
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB 4: COMPLETE HISTORY & AUDIT LOGS */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center bg-indigo-50/50 dark:bg-indigo-950/20 p-4 rounded-2xl border border-indigo-100 dark:border-indigo-900/40">
                <div>
                  <h3 className="font-black text-sm text-indigo-950 dark:text-indigo-200">
                    سجل حركات وتعديلات الحجز (Booking Audit Logs)
                  </h3>
                  <p className="text-xs text-indigo-700/80 dark:text-indigo-400 mt-0.5">
                    تتبع زمني دقيق لكل حركة تمت على حجز الطالب مع بيانات المنفذ وإمكانية التراجع للأدمن.
                  </p>
                </div>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-indigo-600 text-white">
                  {logs.length} حركات
                </span>
              </div>

              {logs.length > 0 ? (
                <div className="space-y-3">
                  {logs.map((log) => {
                    const isReversed = !!log.details?.isReversed;
                    return (
                      <div 
                        key={log.id} 
                        className={`p-4 rounded-2xl border transition-all ${
                          isReversed 
                            ? 'bg-gray-50/60 dark:bg-gray-900/40 border-dashed border-gray-300 dark:border-gray-700 opacity-60' 
                            : 'bg-white dark:bg-gray-800 border-gray-200/80 dark:border-gray-700 shadow-xs'
                        }`}
                      >
                        <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                          <div className="flex items-center gap-2">
                            <span className={`px-2.5 py-1 rounded-xl text-xs font-black border flex items-center gap-1.5 ${getActionColor(log.action)}`}>
                              <i className={`fas ${getActionIcon(log.action)} text-[10px]`}></i>
                              <span>{getActionLabel(log.action)}</span>
                            </span>
                            {isReversed && (
                              <span className="text-[10px] font-bold bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 px-2 py-0.5 rounded-md">
                                [تم التراجع عنها]
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-3 text-xs text-gray-400">
                            <span className="font-mono" dir="ltr">
                              {new Date(log.timestamp).toLocaleString('ar-EG')}
                            </span>
                            {isRollbackable(log) && (
                              <button
                                onClick={() => setConfirmReversal(log)}
                                className="text-xs font-black text-rose-600 hover:text-rose-700 dark:text-rose-400 hover:underline flex items-center gap-1"
                                title="التراجع عن هذه الحركة"
                              >
                                <i className="fas fa-undo text-[10px]"></i>
                                <span>تراجع</span>
                              </button>
                            )}
                          </div>
                        </div>

                        <p className={`text-xs font-semibold text-gray-800 dark:text-gray-200 mb-2 ${isReversed ? 'line-through text-gray-400' : ''}`}>
                          {log.description}
                        </p>

                        {/* Additional Log Details */}
                        {log.details && (
                          <div className="p-3 bg-gray-50 dark:bg-gray-700/40 rounded-xl text-xs space-y-1 text-gray-600 dark:text-gray-300">
                            {log.details.amount !== undefined && (
                              <div>المبلغ: <strong className="text-emerald-600">{log.details.amount} ج.م</strong> {log.details.method ? `(${log.details.method})` : ''}</div>
                            )}
                            {log.details.paymentSummary && (
                              <div>المدفوع: {log.details.paymentSummary.paidTotal} ج.م | المتبقي: {log.details.paymentSummary.remaining} ج.م</div>
                            )}
                            {log.details.reason && (
                              <div>السبب: {log.details.reason}</div>
                            )}
                            {log.details.isReversed && (
                              <div className="text-rose-600 font-bold text-[11px] mt-1">
                                تم التراجع عن الحركة في: {new Date(log.details.reversedAt).toLocaleString('ar-EG')} بواسطة {log.details.reversedBy}
                              </div>
                            )}
                          </div>
                        )}

                        <div className="mt-2 pt-2 border-t dark:border-gray-700/60 flex items-center justify-between text-[11px] text-gray-400">
                          <span>المنفذ: <strong className="text-gray-600 dark:text-gray-300">{resolvePerformer(log.performedBy)}</strong></span>
                          {log.performedByEmail && <span className="text-[10px]">({log.performedByEmail})</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center text-gray-400 bg-gray-50 dark:bg-gray-700/20 rounded-3xl text-xs font-bold">
                  <i className="fas fa-history text-2xl mb-2 block text-gray-300"></i>
                  لا توجد حركات مسجلة في الـ Log حتى الآن لهذا الحجز.
                </div>
              )}
            </div>
          )}

          {/* TAB 5: SALES AGREEMENTS & FOLLOW-UPS */}
          {activeTab === 'agreements' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-2xl border border-amber-200/60 dark:border-amber-900/40">
                <div>
                  <h3 className="font-black text-sm text-amber-950 dark:text-amber-200">
                    سجل متابعة السيلز والاتفاقات لمتبقيات الحجز
                  </h3>
                  <p className="text-xs text-amber-700/80 dark:text-amber-400 mt-0.5">
                    جميع الملاحظات ومواعيد السداد المتفق عليها مع الطالب عبر السيلز.
                  </p>
                </div>
                <span className="text-xs font-black px-3 py-1 rounded-full bg-amber-600 text-white">
                  {agreementNotesHistory.length} متابعات
                </span>
              </div>

              {agreementNotesHistory.length > 0 ? (
                <div className="space-y-3">
                  {agreementNotesHistory.map((note, idx) => (
                    <div key={idx} className="p-4 bg-white dark:bg-gray-800 rounded-2xl border border-amber-100 dark:border-gray-700 space-y-2">
                      <div className="flex justify-between items-center text-xs">
                        <span className="font-black text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                          <i className="fas fa-user-tie text-[10px]"></i>
                          <span>{note.addedByName || 'Sales'}</span>
                        </span>
                        <span className="text-gray-400 text-[10px] font-mono" dir="ltr">
                          {note.timestamp ? new Date(note.timestamp).toLocaleString('ar-EG') : ''}
                        </span>
                      </div>

                      <p className="text-xs font-semibold text-gray-800 dark:text-gray-200 whitespace-pre-wrap leading-relaxed">
                        {note.text}
                      </p>

                      {(note.agreedDate || note.suggestedCount) && (
                        <div className="flex flex-wrap items-center gap-2 pt-1 text-[11px]">
                          {note.agreedDate && (
                            <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 font-bold px-2 py-0.5 rounded-md">
                              الموعد: {note.agreedDate}
                            </span>
                          )}
                          {note.suggestedCount && (
                            <span className="bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 font-bold px-2 py-0.5 rounded-md">
                              {note.suggestedCount} أقساط
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-gray-400 bg-gray-50 dark:bg-gray-700/20 rounded-3xl text-xs font-bold">
                  <i className="fas fa-comments text-2xl mb-2 block text-gray-300"></i>
                  لا توجد متابعات سيلز مسجلة في السجل.
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 md:p-6 border-t dark:border-gray-700/80 bg-gray-50/50 dark:bg-gray-900/30 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs">
            {waUrl && (
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2.5 bg-green-500 hover:bg-green-600 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-sm transition-all text-xs"
              >
                <i className="fab fa-whatsapp"></i>
                <span>مراسلة واتساب</span>
              </a>
            )}
          </div>

          <div className="flex items-center gap-2">
            {hasPermission('editInstallments') && remainingAmount > 0 && onReschedule && (
              <button
                onClick={() => {
                  onClose();
                  onReschedule(booking.id, booking);
                }}
                className="px-5 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-black text-xs shadow-md shadow-amber-500/20 flex items-center gap-1.5 transition-all"
              >
                <i className="fas fa-calendar-plus"></i>
                <span>جدولة الأقساط</span>
              </button>
            )}

            {hasPermission('editInstallments') && remainingAmount > 0 && onPay && (
              <button
                onClick={() => {
                  onClose();
                  onPay(booking.id, remainingAmount);
                }}
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-xs shadow-md shadow-emerald-600/20 flex items-center gap-1.5 transition-all"
              >
                <i className="fas fa-check-circle"></i>
                <span>تحصيل المتبقي</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 rounded-xl font-bold text-xs transition-all"
            >
              إغلاق
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};

export default StudentBookingDetailsModal;
