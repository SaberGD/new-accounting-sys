
import React, { useState, useEffect, useMemo } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { getCorrectDate, getCorrectISOString, getCairoDateString } from '../services/timeService';
import { 
  genericGet, 
  genericGetQuery,
  addPaymentAndUpdateBooking, 
  updateInstallmentDelay, 
  markInstallmentNotified,
  rescheduleRemainingInstallments,
  toggleInstallmentDelayContacted,
  updateInstallmentDelayInfo,
  toggleInstallmentSalesReminder,
  toggleInstallmentSupervisorVerification,
  addInstallmentNote,
  saveUnscheduledAgreement,
  autoReconcileAllInstallmentPlans,
  reconcileInstallmentsForBooking
} from '../services/firestore';
import { where } from 'firebase/firestore';
import { InstallmentPlan, Booking, Customer, Payment, PaymentMethod, Installment, SalesStaff, UnscheduledAgreement, UnscheduledFollowUpNote } from '../types';
import HistoryModal from '../components/HistoryModal';
import StudentBookingDetailsModal from '../components/StudentBookingDetailsModal';

interface DueListItem {
  plan: InstallmentPlan;
  booking: Booking;
  customer: Customer;
  inst: Installment;
  index: number;
}

export interface UnscheduledItem {
  booking: Booking;
  customer: Customer;
  plan?: InstallmentPlan;
  remainingAmount: number;
  paidTotal: number;
  finalPrice: number;
}

interface SalesInstallmentStats {
  salesId: string;
  salesName: string;
  overdueClientsCount: number;
  overdueInstallmentsCount: number;
  overdueTotalAmount: number;
  todayClientsCount: number;
  todayTotalAmount: number;
  unscheduledClientsCount: number;
  unscheduledTotalAmount: number;
}

// Dedicated Card for Unscheduled Installments / Balances with Sales Follow-up & Agreement notes
const UnscheduledCard = React.memo(({ 
  item, 
  userProfile, 
  hasPermission,
  onPay,
  onReschedule,
  onViewHistory,
  onInspect,
  onSaveAgreement
}: {
  item: UnscheduledItem;
  userProfile: any;
  hasPermission: (p: any) => boolean;
  onPay: (bid: string, amt: number) => void;
  onReschedule: (bid: string, booking: Booking) => void;
  onViewHistory: (b: Booking) => void;
  onInspect?: (booking: Booking, customer: Customer, plan?: InstallmentPlan) => void;
  onSaveAgreement: (bid: string, data: { agreementNote: string; agreedDate?: string; suggestedCount?: number }) => Promise<void>;
}) => {
  const { lang } = useTheme();
  const { customer, booking, remainingAmount, paidTotal, finalPrice } = item;
  
  const agreement = booking.unscheduledAgreement;
  const hasAgreement = !!agreement?.agreementNote;

  const [isEditing, setIsEditing] = useState(!hasAgreement);
  const [agreementNote, setAgreementNote] = useState(agreement?.agreementNote || '');
  const [agreedDate, setAgreedDate] = useState(agreement?.agreedDate || '');
  const [suggestedCount, setSuggestedCount] = useState<number>(agreement?.suggestedCount || 1);
  const [showHistory, setShowHistory] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Sync state when booking data updates
  useEffect(() => {
    if (booking.unscheduledAgreement) {
      setAgreementNote(booking.unscheduledAgreement.agreementNote || '');
      setAgreedDate(booking.unscheduledAgreement.agreedDate || '');
      setSuggestedCount(booking.unscheduledAgreement.suggestedCount || 1);
      setIsEditing(false);
    } else {
      setAgreementNote('');
      setAgreedDate('');
      setSuggestedCount(1);
      setIsEditing(true);
    }
  }, [booking.unscheduledAgreement]);

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!agreementNote.trim()) {
      alert(lang === 'ar' ? 'يرجى كتابة تفاصيل الاتفاق أو الملاحظة مع المتدرب' : 'Please enter agreement note');
      return;
    }
    setIsSaving(true);
    try {
      await onSaveAgreement(booking.id, {
        agreementNote: agreementNote.trim(),
        agreedDate: agreedDate || undefined,
        suggestedCount: Number(suggestedCount) || 1
      });
      setSaveSuccess(true);
      setIsEditing(false);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert(lang === 'ar' ? 'حدث خطأ أثناء حفظ الاتفاق' : 'Error saving agreement');
    } finally {
      setIsSaving(false);
    }
  };

  // Format WhatsApp Link
  const rawPhone = customer.whatsapp || customer.phone || '';
  const cleanDigits = rawPhone.replace(/\D/g, '');
  const courseName = (booking as any).productName || (booking as any).courseName || 'الكورس';
  const waMsg = `أهلاً بك يا ${customer.name}، بخصوص كورس ${courseName}، يوجد متبقي مستحق بقيمة ${remainingAmount.toLocaleString()} ج.م نود التنسيق لتأكيد موعد السداد.`;
  
  let formattedWaPhone = cleanDigits;
  if (cleanDigits.startsWith('01')) {
    formattedWaPhone = '20' + cleanDigits.substring(1);
  } else if (!cleanDigits.startsWith('20') && cleanDigits.length === 10 && cleanDigits.startsWith('1')) {
    formattedWaPhone = '20' + cleanDigits;
  }
  const waUrl = formattedWaPhone ? `https://wa.me/${formattedWaPhone}?text=${encodeURIComponent(waMsg)}` : '';

  const bookingProduct = (booking as any).productName || (booking as any).courseName || '';

  return (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border-2 border-amber-300/80 dark:border-amber-600/50 hover:shadow-lg transition-all relative overflow-hidden flex flex-col justify-between">
      {/* Top Banner Tag */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-3 bg-amber-50 dark:bg-amber-950/40 px-3 py-1.5 rounded-xl border border-amber-200/60 dark:border-amber-900/40">
          <span className="flex items-center gap-1.5 text-[10px] font-black text-amber-700 dark:text-amber-300 uppercase tracking-tight">
            <i className="fas fa-calendar-times text-amber-500 animate-pulse"></i>
            {lang === 'ar' ? 'متبقي مالي غير مجدول' : 'Unscheduled Balance'}
          </span>
          <span className="text-[10px] font-bold text-gray-500 dark:text-gray-400">
            {booking.bookingDate ? booking.bookingDate.split('T')[0] : ''}
          </span>
        </div>

        <div className="flex justify-between items-start mb-3">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              {onInspect ? (
                <button 
                  type="button"
                  onClick={() => onInspect(booking, customer, item.plan)}
                  className="font-bold text-lg text-gray-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 text-right flex items-center gap-1.5 transition-colors group cursor-pointer"
                  title={lang === 'ar' ? 'عرض بيانات الطالب + تفاصيل الحجز وسجل الحركات' : 'View Student & Booking Details and History'}
                >
                  <span>{customer.name}</span>
                  <i className="fas fa-id-card text-xs text-indigo-500 opacity-60 group-hover:opacity-100 transition-opacity"></i>
                </button>
              ) : (
                <h3 className="font-bold text-lg text-gray-900 dark:text-white">{customer.name}</h3>
              )}
              {hasPermission('viewHistory') && (
                <button onClick={() => onViewHistory(booking)} className="text-gray-400 hover:text-indigo-500 transition-colors" title="View History Log">
                  <i className="fas fa-history text-xs"></i>
                </button>
              )}
            </div>
            <p className="text-xs text-gray-500 font-medium">{customer.whatsapp || customer.phone || 'بدون رقم'}</p>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              <span className="text-[9px] font-black bg-primary-50 dark:bg-primary-900/20 text-primary-600 px-2 py-0.5 rounded uppercase">
                <i className="fas fa-user-tie mr-1"></i> {booking.salesName || 'Unknown Sales'}
              </span>
              {bookingProduct && (
                <span className="text-[9px] font-black bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded">
                  {bookingProduct}
                </span>
              )}
            </div>
          </div>

          <div className="text-right">
            <p className="text-[9px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest mb-0.5">{lang === 'ar' ? 'المبلغ المتبقي' : 'Remaining'}</p>
            <p className="text-2xl font-black text-amber-600 dark:text-amber-400">{remainingAmount.toLocaleString()} ج.م</p>
          </div>
        </div>

        {/* Dedicated Inspector Button for Student Profile, Booking Details & Audit History */}
        {onInspect && (
          <button 
            type="button"
            onClick={() => onInspect(booking, customer, item.plan)}
            className="w-full flex items-center justify-center gap-2 py-2.5 mb-3 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 font-black text-xs rounded-2xl border border-indigo-200 dark:border-indigo-800 transition-all shadow-xs cursor-pointer group"
          >
            <i className="fas fa-id-card-clip text-indigo-600 dark:text-indigo-400 group-hover:scale-110 transition-transform"></i>
            <span>{lang === 'ar' ? 'بيانات الطالب + تفاصيل الحجز والسجل' : 'Student Profile & Booking History'}</span>
            <i className="fas fa-arrow-left text-[10px] opacity-70 group-hover:-translate-x-0.5 transition-transform"></i>
          </button>
        )}

        {/* Financial Progress Bar */}
        <div className="mb-3 bg-gray-50 dark:bg-gray-700/50 p-3 rounded-2xl border border-gray-100 dark:border-gray-600/50">
          <div className="flex justify-between items-center text-xs mb-1.5">
            <span className="text-gray-500 dark:text-gray-400 font-medium">
              {lang === 'ar' ? 'المدفوع: ' : 'Paid: '}
              <strong className="text-emerald-600 dark:text-emerald-400 font-bold">{paidTotal.toLocaleString()} ج.م</strong>
            </span>
            <span className="text-gray-500 dark:text-gray-400 font-medium">
              {lang === 'ar' ? 'الإجمالي: ' : 'Total: '}
              <strong className="text-gray-800 dark:text-gray-200 font-bold">{finalPrice.toLocaleString()} ج.م</strong>
            </span>
          </div>
          <div className="w-full h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
            <div 
              className="h-full bg-emerald-500 rounded-full transition-all" 
              style={{ width: `${Math.min(100, Math.round((paidTotal / (finalPrice || 1)) * 100))}%` }}
            ></div>
          </div>
        </div>

        {/* Sales Follow-up & Agreement Note Area */}
        <div className="mb-4 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40 rounded-2xl p-3.5 relative">
          {saveSuccess && (
            <div className="absolute top-2 left-2 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-md shadow-sm animate-bounce flex items-center gap-1 z-10">
              <i className="fas fa-check"></i> {lang === 'ar' ? 'تم حفظ الاتفاق' : 'Saved'}
            </div>
          )}

          {!isEditing && hasAgreement ? (
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="flex items-center gap-1.5 text-[11px] font-black text-amber-800 dark:text-amber-200">
                  <i className="fas fa-comments text-amber-500"></i>
                  {lang === 'ar' ? 'اتفاق السيلز والمتابعة للجدولة' : 'Sales Agreement / Follow-up'}
                </span>
                <button 
                  onClick={() => setIsEditing(true)}
                  className="text-[10px] font-bold text-amber-700 hover:text-amber-900 dark:text-amber-300 dark:hover:text-white bg-amber-100/70 hover:bg-amber-200/80 dark:bg-amber-900/40 px-2 py-0.5 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  title="تعديل الاتفاق"
                >
                  <i className="fas fa-pen text-[9px]"></i>
                  <span>{lang === 'ar' ? 'تعديل الاتفاق' : 'Edit'}</span>
                </button>
              </div>

              {/* Note Content */}
              <div className="bg-white/90 dark:bg-gray-800/90 p-2.5 rounded-xl border border-amber-200/50 dark:border-amber-900/30 text-xs font-semibold text-gray-800 dark:text-gray-200 whitespace-pre-wrap leading-relaxed">
                {agreement.agreementNote}
              </div>

              {/* Metadata Badges */}
              <div className="mt-2.5 flex flex-wrap items-center gap-2 text-[10px]">
                {agreement.agreedDate && (
                  <span className="flex items-center gap-1 font-bold bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-lg border border-blue-200/60 dark:border-blue-800/40">
                    <i className="fas fa-calendar-check text-blue-500"></i>
                    <span>{lang === 'ar' ? 'الموعد المتفق عليه:' : 'Agreed Date:'} {agreement.agreedDate}</span>
                  </span>
                )}
                {agreement.suggestedCount && agreement.suggestedCount > 0 && (
                  <span className="flex items-center gap-1 font-bold bg-purple-50 dark:bg-purple-950/40 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded-lg border border-purple-200/60 dark:border-purple-800/40">
                    <i className="fas fa-list-ol text-purple-500"></i>
                    <span>
                      {agreement.suggestedCount} {lang === 'ar' ? 'أقساط' : 'installments'} 
                      {` (~${Math.round(remainingAmount / agreement.suggestedCount).toLocaleString()} ج.م)`}
                    </span>
                  </span>
                )}
                {agreement.updatedByName && (
                  <span className="text-gray-500 dark:text-gray-400 font-medium">
                    <i className="fas fa-user-check mr-1 text-[9px]"></i>
                    {agreement.updatedByName}
                  </span>
                )}
              </div>

              {/* History Toggle if exists */}
              {agreement.notesHistory && agreement.notesHistory.length > 1 && (
                <div className="mt-2 pt-2 border-t border-amber-200/40 dark:border-amber-900/30">
                  <button
                    onClick={() => setShowHistory(!showHistory)}
                    className="text-[10px] font-bold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <i className={`fas fa-chevron-${showHistory ? 'up' : 'down'} text-[8px]`}></i>
                    <span>{lang === 'ar' ? `عرض سجل الاتفاقات السابقة (${agreement.notesHistory.length})` : `View history (${agreement.notesHistory.length})`}</span>
                  </button>

                  {showHistory && (
                    <div className="mt-2 space-y-1.5 max-h-32 overflow-y-auto pr-1">
                      {agreement.notesHistory.map((nh, nIdx) => (
                        <div key={nIdx} className="bg-white/60 dark:bg-gray-800/60 p-2 rounded-lg text-[10px] border border-gray-100 dark:border-gray-700">
                          <div className="flex justify-between items-center text-gray-500 dark:text-gray-400 mb-0.5">
                            <span className="font-bold text-gray-700 dark:text-gray-300">{nh.addedByName || 'Sales'}</span>
                            <span>{nh.timestamp ? nh.timestamp.split('T')[0] : ''}</span>
                          </div>
                          <p className="text-gray-800 dark:text-gray-200">{nh.text}</p>
                          {nh.agreedDate && <p className="text-blue-600 dark:text-blue-400 text-[9px] mt-0.5">الموعد: {nh.agreedDate}</p>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          ) : (
            <form onSubmit={handleSave} className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <label className="text-[11px] font-black text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                  <i className="fas fa-pen-to-square text-amber-600"></i>
                  <span>{hasAgreement ? (lang === 'ar' ? 'تعديل اتفاق السيلز والموعد' : 'Update Agreement') : (lang === 'ar' ? 'تسجيل اتفاق السيلز مع المتدرب' : 'Record Sales Agreement')}</span>
                </label>
                {hasAgreement && (
                  <button 
                    type="button" 
                    onClick={() => setIsEditing(false)}
                    className="text-[10px] font-bold text-gray-500 hover:text-gray-700 dark:text-gray-400"
                  >
                    {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>
                )}
              </div>

              <textarea 
                rows={2}
                value={agreementNote}
                onChange={e => setAgreementNote(e.target.value)}
                placeholder={lang === 'ar' ? 'اكتب تفاصيل الاتفاق (مثال: تم التواصل واتفقنا على سداد 1000 ج.م الأسبوع القادم وباقي المبلغ أول الشهر)...' : 'Write sales agreement details (e.g. promised date, payment method, installment agreement)...'}
                className="w-full text-xs p-2.5 rounded-xl border border-amber-300 dark:border-amber-700 bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
              />

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-bold text-gray-600 dark:text-gray-400 block mb-0.5">
                    <i className="fas fa-calendar-alt text-amber-500 mr-1"></i>
                    {lang === 'ar' ? 'الموعد المتفق عليه' : 'Agreed Date'}
                  </label>
                  <input 
                    type="date"
                    value={agreedDate}
                    onChange={e => setAgreedDate(e.target.value)}
                    className="w-full text-xs p-1.5 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="text-[9px] font-bold text-gray-600 dark:text-gray-400 block mb-0.5">
                    <i className="fas fa-list-ol text-purple-500 mr-1"></i>
                    {lang === 'ar' ? 'عدد الأقساط المقترحة' : 'Suggested Count'}
                  </label>
                  <input 
                    type="number"
                    min="1"
                    max="12"
                    value={suggestedCount}
                    onChange={e => setSuggestedCount(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full text-xs p-1.5 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="submit"
                  disabled={isSaving || !agreementNote.trim()}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 disabled:opacity-50 active:scale-95 text-white font-bold text-xs rounded-xl shadow-sm transition-all cursor-pointer"
                >
                  <i className={`fas ${isSaving ? 'fa-spinner fa-spin' : 'fa-save'}`}></i>
                  <span>{isSaving ? (lang === 'ar' ? 'جاري الحفظ...' : 'Saving...') : (lang === 'ar' ? 'حفظ الاتفاق' : 'Save Agreement')}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-3 border-t border-gray-100 dark:border-gray-700">
        {hasPermission('editInstallments') ? (
          <>
            <button 
              onClick={() => onReschedule(booking.id, booking)} 
              className="flex items-center justify-center gap-1.5 py-2.5 bg-amber-500 hover:bg-amber-600 active:scale-95 text-white font-black text-xs rounded-xl shadow-sm transition-all cursor-pointer"
              title={hasAgreement ? 'جدولة الأقساط وتطبيق الاتفاق المسجل' : 'جدولة الأقساط'}
            >
              <i className="fas fa-calendar-plus text-xs"></i>
              <span>{hasAgreement ? (lang === 'ar' ? '⚡ جدولة حسب الاتفاق' : 'Schedule Plan') : (lang === 'ar' ? '⚡ جدولة الأقساط' : 'Schedule Plan')}</span>
            </button>

            <button 
              onClick={() => onPay(booking.id, remainingAmount)} 
              className="flex items-center justify-center gap-1.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-sm transition-all cursor-pointer"
            >
              <i className="fas fa-check-circle text-xs"></i>
              <span>{lang === 'ar' ? '💳 تحصيل الآن' : 'Pay Balance'}</span>
            </button>
          </>
        ) : (
          <div className="col-span-2 flex items-center justify-center py-2 bg-gray-50 dark:bg-gray-700/50 rounded-xl text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            <i className="fas fa-info-circle mr-2"></i> View Only
          </div>
        )}

        {waUrl && (
          <a 
            href={waUrl} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="col-span-2 flex items-center justify-center gap-1.5 py-2 bg-green-50 hover:bg-green-100 dark:bg-green-950/20 dark:hover:bg-green-900/30 text-green-700 dark:text-green-400 font-bold text-xs rounded-xl border border-green-200 dark:border-green-800/40 transition-colors"
          >
            <i className="fab fa-whatsapp text-sm text-green-600"></i>
            <span>{lang === 'ar' ? 'مراسلة واتساب للتنسيق' : 'Contact via WhatsApp'}</span>
          </a>
        )}
      </div>
    </div>
  );
});


// Memoized Installment Card for high performance
const InstallmentCard = React.memo(({ 
  item, 
  userProfile, 
  hasPermission,
  onMarkNotified,
  onToggleDelayContacted,
  onPay,
  onReschedule,
  onUpdateDelayTracking,
  toggleSalesReminder,
  toggleSupervisorVerify,
  onAddNote,
  onViewHistory,
  onInspect
}: {
  item: DueListItem;
  userProfile: any;
  hasPermission: (p: any) => boolean;
  onMarkNotified: (bid: string, idx: number) => void;
  onToggleDelayContacted: (bid: string, idx: number) => void;
  onPay: (bid: string, idx: number, amt: number) => void;
  onReschedule: (bid: string, idx: number, booking: Booking) => void;
  onUpdateDelayTracking: (item: DueListItem) => void;
  toggleSalesReminder: (bid: string, idx: number) => void;
  toggleSupervisorVerify: (bid: string, idx: number) => void;
  onAddNote: (bid: string, idx: number) => void;
  onViewHistory: (b: Booking) => void;
  onInspect?: (booking: Booking, customer: Customer, plan?: InstallmentPlan) => void;
}) => {
  const { plan, customer, inst, index, booking } = item;
  
  return (
    <div className={`bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border ${inst.label ? 'border-primary-500 bg-primary-50/10' : 'border-gray-100 dark:border-gray-700'} hover:shadow-lg transition-shadow`}>
      <div className="flex justify-between items-start mb-4">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            {onInspect ? (
              <button 
                type="button"
                onClick={() => onInspect(booking, customer, plan)}
                className="font-bold text-lg text-gray-900 dark:text-white hover:text-indigo-600 dark:hover:text-indigo-400 text-right flex items-center gap-1.5 transition-colors group cursor-pointer"
                title="عرض بيانات الطالب والحجز والسجل"
              >
                <span>{customer.name}</span>
                <i className="fas fa-id-card text-xs text-indigo-500 opacity-60 group-hover:opacity-100 transition-opacity"></i>
              </button>
            ) : (
              <h3 className="font-bold text-lg">{customer.name}</h3>
            )}
            {hasPermission('viewHistory') && (
              <button onClick={() => onViewHistory(booking)} className="text-gray-400 hover:text-indigo-500 transition-colors" title="View History Log">
                <i className="fas fa-history text-xs"></i>
              </button>
            )}
          </div>
          <p className="text-xs text-gray-500">{customer.whatsapp}</p>
          <div className="mt-1 flex items-center gap-1.5">
            <span className="text-[9px] font-black bg-primary-50 dark:bg-primary-900/20 text-primary-600 px-1.5 py-0.5 rounded uppercase tracking-tighter">
              <i className="fas fa-user-tie mr-1"></i> {booking.salesName || 'Unknown Sales'}
            </span>
            {plan.planLabel && (
              <span className="text-[9px] font-black bg-amber-50 dark:bg-amber-900/20 text-amber-600 px-1.5 py-0.5 rounded uppercase tracking-tighter border border-amber-100 dark:border-amber-900/30">
                <i className="fas fa-file-invoice-dollar mr-1"></i> {plan.planLabel}
              </span>
            )}
          </div>
        </div>
        <div className="text-right">
          {inst.label && <p className="text-[8px] font-black text-primary-500 uppercase mb-1">{inst.label}</p>}
          <p className="text-xl font-black text-primary-600">{inst.amount.toLocaleString()} ج.م</p>
          <p className="text-[10px] text-gray-400 font-bold uppercase">{inst.dueDate}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-3 gap-2 py-3 border-y border-gray-50 dark:border-gray-700/50 mb-4">
        <div className="text-center">
          <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Total Price</p>
          <p className="text-[11px] font-bold">{booking.pricing.finalPriceSnapshot.toLocaleString()}</p>
        </div>
        <div className="text-center border-x border-gray-50 dark:border-gray-700/50">
          <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Paid Total</p>
          <p className="text-[11px] font-bold text-green-600">{booking.paymentSummary.paidTotal.toLocaleString()}</p>
        </div>
        <div className="text-center">
          <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Remaining</p>
          <p className="text-[11px] font-bold text-red-500">{booking.paymentSummary.remaining.toLocaleString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mt-2">
        {hasPermission('editInstallments') ? (
          <>
            <button onClick={() => onPay(plan.bookingId, index, inst.amount)} className="py-2.5 bg-green-600 text-white rounded-xl text-xs font-bold shadow-lg shadow-green-500/20">Pay</button>
            <button onClick={() => onReschedule(plan.bookingId, index, booking)} className="py-2.5 bg-amber-500 text-white rounded-xl text-xs font-bold">Reschedule</button>
          </>
        ) : (
          <div className="col-span-2 flex items-center justify-center bg-gray-50 dark:bg-gray-700/50 rounded-xl text-[10px] font-bold text-gray-400 uppercase tracking-widest">
            <i className="fas fa-info-circle mr-2"></i> View Only
          </div>
        )}
        <button onClick={() => onMarkNotified(plan.bookingId, index)} className={`py-2.5 rounded-xl text-xs font-bold border transition-colors ${inst.notifiedOnWhatsApp ? 'bg-green-50 text-green-600 border-green-200' : 'bg-gray-50 dark:bg-gray-700 text-gray-400'}`}><i className="fab fa-whatsapp mr-1"></i> Notified</button>
      </div>

      <div className="grid grid-cols-2 gap-4 mt-4 p-3 bg-gray-50/50 dark:bg-gray-700/30 rounded-2xl border border-gray-100 dark:border-gray-700">
        <div className={`flex flex-col gap-1 p-2 rounded-xl transition-all ${inst.remindedBySales ? 'bg-blue-50/50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-900/30' : 'border border-transparent'}`}>
          <label className="flex items-center gap-2 cursor-pointer group">
            <input 
              type="checkbox" 
              checked={!!inst.remindedBySales} 
              onChange={() => toggleSalesReminder(plan.bookingId, index)}
              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 transition-transform group-hover:scale-110"
            />
            <span className={`text-[10px] font-black uppercase transition-colors ${inst.remindedBySales ? 'text-blue-600' : 'text-gray-500'}`}>Sales Reminder</span>
          </label>
          {inst.remindedBySales && (
            <p className="text-[9px] text-blue-600 font-bold ml-6 animate-in fade-in slide-in-from-left-1">
               <i className="fas fa-check-circle mr-1"></i>
               {inst.remindedBySales.name}
            </p>
          )}
        </div>
        <div className="flex flex-col gap-1">
          <label className="flex items-center gap-2 cursor-pointer">
            <input 
              type="checkbox" 
              checked={!!inst.verifiedBySupervisor} 
              disabled={userProfile?.role !== 'supervisor' && userProfile?.role !== 'manager' && userProfile?.role !== 'admin'}
              onChange={() => toggleSupervisorVerify(plan.bookingId, index)}
              className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500"
            />
            <span className="text-[10px] font-black text-gray-500 uppercase">Supervisor Verify</span>
          </label>
          {inst.verifiedBySupervisor && (
            <p className="text-[9px] text-purple-600 font-bold ml-6">
               <i className="fas fa-shield-alt mr-1"></i>
               {inst.verifiedBySupervisor.name}
            </p>
          )}
        </div>
      </div>

      <div className="mt-4">
        <button 
          onClick={() => onAddNote(plan.bookingId, index)}
          className={`w-full py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border ${
            inst.notes && inst.notes.length > 0 
              ? 'bg-indigo-50 border-indigo-200 text-indigo-600 shadow-lg shadow-indigo-500/20' 
              : 'bg-gray-50 dark:bg-gray-700/50 border-transparent text-gray-400'
          }`}
        >
          <i className="fas fa-sticky-note mr-2"></i>
          {inst.notes && inst.notes.length > 0 ? `Notes (${inst.notes.length})` : 'Add Note (Optional)'}
        </button>
        {inst.notes && inst.notes.length > 0 && (
          <div className="mt-2 space-y-1.5 max-h-32 overflow-y-auto pr-1">
            {inst.notes.map((n, idx) => (
              <div key={idx} className="bg-white dark:bg-gray-700 p-2 rounded-lg border border-indigo-50 dark:border-indigo-900/30 text-[10px]">
                <p className="text-gray-700 dark:text-gray-200 font-medium mb-1">{n.text}</p>
                <div className="flex justify-between items-center text-[8px] font-bold text-indigo-400 uppercase">
                  <span>{n.addedByName}</span>
                  <span>{new Date(n.timestamp).toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <div className="mt-4 pt-4 border-t border-dashed border-gray-100 dark:border-gray-700">
        <div className="flex items-center justify-between mb-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input 
              type="checkbox" 
              checked={inst.delayContacted || false} 
              onChange={() => onToggleDelayContacted(plan.bookingId, index)}
              className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500"
            />
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tight">تم التواصل بخصوص التأخير</span>
          </label>
          {inst.delayReason && (
            <span className="text-[9px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">مؤجل</span>
          )}
        </div>
        
        {inst.delayReason && (
          <div className="mb-3 p-2 bg-amber-50/50 dark:bg-amber-900/10 rounded-lg border border-amber-100 dark:border-amber-900/30">
            <p className="text-[10px] text-amber-700 font-medium leading-relaxed">
              <i className="fas fa-comment-dots mr-1"></i> {inst.delayReason}
            </p>
            {inst.originalDueDate && (
              <p className="text-[8px] text-amber-600 mt-1 italic">الموعد الأصلي: {inst.originalDueDate}</p>
            )}
          </div>
        )}

        <button 
          onClick={() => onUpdateDelayTracking(item)}
          className="w-full py-2 bg-gray-50 dark:bg-gray-700 hover:bg-amber-50 dark:hover:bg-amber-900/20 text-gray-500 hover:text-amber-600 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-transparent hover:border-amber-200"
        >
          <i className="fas fa-calendar-plus mr-1"></i> {inst.delayReason ? 'تعديل بيانات التأخير' : 'إضافة سبب التأخير والموعد الجديد'}
        </button>
      </div>
    </div>
  );
});

const Installments: React.FC = () => {
  const { t, lang } = useTheme();
  const { effectiveProfile, hasPermission } = useAuth();
  const userProfile = effectiveProfile;
  const [activeTab, setActiveTab] = useState<'today' | 'soon' | 'overdue' | 'unscheduled' | 'all'>('today');

  if (!hasPermission('viewInstallments')) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 text-red-500 rounded-full flex items-center justify-center mb-6 text-3xl">
          <i className="fas fa-lock"></i>
        </div>
        <h2 className="text-2xl font-black uppercase tracking-tight mb-2">Access Denied</h2>
        <p className="text-gray-500 max-w-md">You do not have permission to view financial installments or collection data.</p>
      </div>
    );
  }
  const [plans, setPlans] = useState<InstallmentPlan[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [salesStaff, setSalesStaff] = useState<SalesStaff[]>([]);

  // Memoized maps for O(1) lookups
  const bookingsMap = useMemo(() => {
    const map = new Map<string, Booking>();
    bookings.forEach(b => map.set(b.id, b));
    return map;
  }, [bookings]);

  const plansMap = useMemo(() => {
    const map = new Map<string, InstallmentPlan>();
    plans.forEach(p => map.set(p.bookingId, p));
    return map;
  }, [plans]);

  const customersMap = useMemo(() => {
    const map = new Map<string, Customer>();
    customers.forEach(c => map.set(c.id, c));
    return map;
  }, [customers]);

  const salesStaffMap = useMemo(() => {
    const map = new Map<string, SalesStaff>();
    salesStaff.forEach(s => map.set(s.id, s));
    return map;
  }, [salesStaff]);

  const salesStats = useMemo(() => {
    const todayStr = getCairoDateString();
    const statsMap = new Map<string, {
      salesName: string;
      overdueCustomers: Set<string>;
      overdueInstCount: number;
      overdueAmount: number;
      todayCustomers: Set<string>;
      todayAmount: number;
      unscheduledCustomers: Set<string>;
      unscheduledAmount: number;
    }>();

    const getEntry = (salesId: string, salesName: string) => {
      if (!statsMap.has(salesId)) {
        statsMap.set(salesId, {
          salesName: salesName || 'Unknown Sales',
          overdueCustomers: new Set<string>(),
          overdueInstCount: 0,
          overdueAmount: 0,
          todayCustomers: new Set<string>(),
          todayAmount: 0,
          unscheduledCustomers: new Set<string>(),
          unscheduledAmount: 0,
        });
      }
      return statsMap.get(salesId)!;
    };

    plans.forEach(plan => {
      const booking = bookingsMap.get(plan.bookingId);
      if (!booking || (booking.status && booking.status !== 'ACTIVE' && (booking.status as string) !== 'active') || booking.isDeleted) return;
      if (booking.paymentSummary && booking.paymentSummary.remaining <= 0) return;

      const salesId = booking.salesId || 'unknown';
      const salesName = booking.salesName || 'Unknown Sales';

      plan.installments.forEach(inst => {
        if (inst.status === 'paid' || inst.status === 'cancelled') return;

        const isOverdue = inst.dueDate < todayStr;
        const isToday = inst.dueDate === todayStr;

        if (isOverdue) {
          const entry = getEntry(salesId, salesName);
          entry.overdueCustomers.add(booking.customerId);
          entry.overdueInstCount += 1;
          entry.overdueAmount += inst.amount;
        } else if (isToday) {
          const entry = getEntry(salesId, salesName);
          entry.todayCustomers.add(booking.customerId);
          entry.todayAmount += inst.amount;
        }
      });
    });

    // Unscheduled bookings tracking
    bookings.forEach(booking => {
      if (booking.isDeleted === true) return;
      if (booking.status && booking.status !== 'ACTIVE' && (booking.status as string) !== 'active') return;
      const remaining = booking.paymentSummary?.remaining ?? 0;
      if (remaining <= 0) return;

      const plan = plansMap.get(booking.id);
      const activePending = plan ? (plan.installments || []).filter(i => i.status === 'pending' || i.status === 'delayed') : [];
      if (activePending.length === 0) {
        const salesId = booking.salesId || 'unknown';
        const salesName = booking.salesName || 'Unknown Sales';
        const entry = getEntry(salesId, salesName);
        entry.unscheduledCustomers.add(booking.customerId);
        entry.unscheduledAmount += remaining;
      }
    });

    const list: SalesInstallmentStats[] = [];
    statsMap.forEach((val, key) => {
      list.push({
        salesId: key,
        salesName: val.salesName,
        overdueClientsCount: val.overdueCustomers.size,
        overdueInstallmentsCount: val.overdueInstCount,
        overdueTotalAmount: val.overdueAmount,
        todayClientsCount: val.todayCustomers.size,
        todayTotalAmount: val.todayAmount,
        unscheduledClientsCount: val.unscheduledCustomers.size,
        unscheduledTotalAmount: val.unscheduledAmount,
      });
    });

    // Filter based on permissions: if sales staff, only show their own
    const canSeeAll = hasPermission('viewAllBookings');
    const linkedStaff = salesStaff.find(s => s.userId === userProfile?.uid);

    if (!canSeeAll && linkedStaff) {
      return list.filter(item => item.salesId === linkedStaff.id);
    }

    return list.sort((a, b) => (b.overdueTotalAmount + b.todayTotalAmount + b.unscheduledTotalAmount) - (a.overdueTotalAmount + a.todayTotalAmount + a.unscheduledTotalAmount));
  }, [plans, bookings, bookingsMap, plansMap, salesStaff, userProfile, hasPermission]);

  const [loading, setLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isReconciling, setIsReconciling] = useState(false);

  const handleReconcileAll = async () => {
    setIsReconciling(true);
    try {
      const res = await autoReconcileAllInstallmentPlans();
      await fetchData();
      if (res.reconciledCount > 0) {
        alert(lang === 'ar' 
          ? `✅ تم فحص ${res.totalChecked} حجز، وتمت مزامنة وإصلاح ${res.reconciledCount} خطة أقساط بنجاح!` 
          : `✅ Checked ${res.totalChecked} bookings, repaired ${res.reconciledCount} installment plans successfully!`);
      } else {
        alert(lang === 'ar' 
          ? `✅ جميع خطط الأقساط متطابقة وسليمة 100% مع المدفوعات الفعلية (${res.totalChecked} حجز).` 
          : `✅ All installment plans are 100% healthy and in sync with actual payments (${res.totalChecked} bookings checked).`);
      }
    } catch (e) {
      console.error("Error running reconciliation:", e);
      alert("حدث خطأ أثناء مزامنة الأقساط. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsReconciling(false);
    }
  };

  const handleToggleSalesReminder = React.useCallback(async (bookingId: string, index: number) => {
    if (!userProfile) return;
    const originalState = [...plans];
    
    // Optimistic Update
    setPlans(prev => prev.map(p => {
      if (p.bookingId === bookingId) {
        const newInst = p.installments.map((inst, i) => {
          if (i === index) {
            const updated = { ...inst };
            if (updated.remindedBySales) {
              delete updated.remindedBySales;
            } else {
              updated.remindedBySales = { 
                uid: userProfile.uid, 
                name: userProfile.displayName, 
                timestamp: getCorrectISOString() 
              };
            }
            return updated;
          }
          return inst;
        });
        return { ...p, installments: newInst };
      }
      return p;
    }));

    try {
      await toggleInstallmentSalesReminder(bookingId, index, { uid: userProfile.uid, name: userProfile.displayName });
    } catch (err) {
      setPlans(originalState);
      alert("Error updating sales reminder");
    }
  }, [userProfile, plans]);

  const handleToggleSupervisorVerify = React.useCallback(async (bookingId: string, index: number) => {
    if (!userProfile) return;
    const originalState = [...plans];

    setPlans(prev => prev.map(p => {
      if (p.bookingId === bookingId) {
        const newInst = p.installments.map((inst, i) => {
          if (i === index) {
            const updated = { ...inst };
            if (updated.verifiedBySupervisor) {
              delete updated.verifiedBySupervisor;
            } else {
              updated.verifiedBySupervisor = { 
                uid: userProfile.uid, 
                name: userProfile.displayName, 
                timestamp: getCorrectISOString() 
              };
            }
            return updated;
          }
          return inst;
        });
        return { ...p, installments: newInst };
      }
      return p;
    }));

    try {
      await toggleInstallmentSupervisorVerification(bookingId, index, { uid: userProfile.uid, name: userProfile.displayName });
    } catch (err) {
      setPlans(originalState);
      alert("Error updating supervisor verification");
    }
  }, [userProfile, plans]);

  const handleSaveUnscheduledAgreement = React.useCallback(async (
    bookingId: string,
    data: { agreementNote: string; agreedDate?: string; suggestedCount?: number }
  ) => {
    if (!userProfile) return;
    const originalBookings = [...bookings];

    const nowIso = getCorrectISOString();
    const newHistoryItem: UnscheduledFollowUpNote = {
      text: data.agreementNote,
      agreedDate: data.agreedDate,
      suggestedCount: data.suggestedCount,
      addedBy: userProfile.uid,
      addedByName: userProfile.displayName,
      timestamp: nowIso
    };

    // Optimistic Update
    setBookings(prev => prev.map(b => {
      if (b.id === bookingId) {
        const prevHistory = b.unscheduledAgreement?.notesHistory || [];
        const updatedAgreement: UnscheduledAgreement = {
          agreementNote: data.agreementNote,
          agreedDate: data.agreedDate || '',
          suggestedCount: data.suggestedCount || 1,
          updatedBy: userProfile.uid,
          updatedByName: userProfile.displayName,
          updatedAt: nowIso,
          notesHistory: [newHistoryItem, ...prevHistory]
        };
        return { ...b, unscheduledAgreement: updatedAgreement };
      }
      return b;
    }));

    try {
      await saveUnscheduledAgreement(bookingId, {
        agreementNote: data.agreementNote,
        agreedDate: data.agreedDate,
        suggestedCount: data.suggestedCount,
        user: { uid: userProfile.uid, name: userProfile.displayName, email: userProfile.email }
      });
    } catch (err) {
      console.error("Error saving unscheduled agreement:", err);
      setBookings(originalBookings);
      throw err;
    }
  }, [userProfile, bookings]);

  // Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState({ start: '', end: '' });
  const [selectedSalesId, setSelectedSalesId] = useState('all');
  const [groupBy, setGroupBy] = useState<'none' | 'sales' | 'date'>('none');

  // Actions State
  const [delayModal, setDelayModal] = useState<{ planId: string, index: number, booking: Booking } | null>(null);
  const [delayData, setDelayData] = useState({ reason: '', date: '', newCount: 1 });
  
  // Reschedule State
  const [reschedulePlan, setReschedulePlan] = useState<Installment[]>([]);
  const [useUniformInterval, setUseUniformInterval] = useState(false);
  const [uniformDays, setUniformDays] = useState(30);

  const [paymentModal, setPaymentModal] = useState<{ planId: string, index: number, amount: number } | null>(null);
  const [paymentData, setPaymentData] = useState({ method: 'cash_office' as PaymentMethod, ref: '', note: '', receiptLink: '' });

  const [delayTrackingModal, setDelayTrackingModal] = useState<{ planId: string, index: number, inst: Installment, booking: Booking } | null>(null);
  const [delayTrackingData, setDelayTrackingData] = useState({ reason: '', newDate: '', installments: [] as Installment[] });

  const [isHistoryModalOpen, setHistoryModalOpen] = useState(false);
  const [activeHistoryBooking, setActiveHistoryBooking] = useState<Booking | null>(null);
  const [studentBookingModal, setStudentBookingModal] = useState<{
    booking: Booking;
    customer: Customer;
    plan?: InstallmentPlan;
  } | null>(null);

  const handleMarkNotified = React.useCallback(async (bookingId: string, index: number) => {
    const originalState = [...plans];
    // Optimistic Update
    setPlans(prev => prev.map(p => {
      if (p.bookingId === bookingId) {
        const newInst = [...p.installments];
        if (newInst[index]) {
          newInst[index] = { ...newInst[index], notifiedOnWhatsApp: !newInst[index].notifiedOnWhatsApp };
        }
        return { ...p, installments: newInst };
      }
      return p;
    }));

    try {
      const performedBy = userProfile ? { name: userProfile.displayName, email: userProfile.email } : undefined;
      await markInstallmentNotified(bookingId, index, performedBy);
    } catch (err) {
      console.error("Failed to toggle notified status:", err);
      setPlans(originalState);
      alert("حدث خطأ أثناء تحديث الحالة. يرجى المحاولة مرة أخرى.");
    }
  }, [userProfile, plans]);

  const handleToggleDelayContacted = React.useCallback(async (bookingId: string, index: number) => {
    const originalState = [...plans];
    // Optimistic Update
    setPlans(prev => prev.map(p => {
      if (p.bookingId === bookingId) {
        const newInst = [...p.installments];
        if (newInst[index]) {
          newInst[index] = { ...newInst[index], delayContacted: !newInst[index].delayContacted };
        }
        return { ...p, installments: newInst };
      }
      return p;
    }));

    try {
      const performedBy = userProfile ? { name: userProfile.displayName, email: userProfile.email } : undefined;
      await toggleInstallmentDelayContacted(bookingId, index, performedBy);
    } catch (err) {
      console.error("Failed to toggle delay contacted status:", err);
      setPlans(originalState);
      alert("Failed to update status. Please try again.");
    }
  }, [userProfile, plans]);

  const handleUpdateDelayTracking = async () => {
    if (!delayTrackingModal) return;
    if (!delayTrackingData.reason.trim()) {
      alert("يجب كتابة سبب التأخير أو تفاصيل ما تم الاتفاق عليه");
      return;
    }
    setIsProcessing(true);
    try {
      const performedBy = userProfile ? { name: userProfile.displayName, email: userProfile.email } : undefined;
      await updateInstallmentDelayInfo(
        delayTrackingModal.planId, 
        delayTrackingModal.index, 
        delayTrackingData.installments, 
        delayTrackingData.reason, 
        performedBy
      );
      setDelayTrackingModal(null);
      fetchData();
    } catch (err) {
      console.error("Failed to update delay info:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDelayTrackingLocalEdit = (idx: number, field: 'dueDate' | 'amount', value: any) => {
    const updated = [...delayTrackingData.installments];
    if (!updated[idx]) return;

    if (field === 'dueDate') {
        const oldDate = new Date(updated[idx].dueDate);
        const newDate = new Date(value);
        
        updated[idx].dueDate = value;

        if (useUniformInterval) {
            for (let i = idx + 1; i < updated.length; i++) {
                const prevDate = new Date(updated[i-1].dueDate);
                prevDate.setDate(prevDate.getDate() + uniformDays);
                updated[i].dueDate = prevDate.toISOString().split('T')[0];
            }
        } else {
            const diffTime = newDate.getTime() - oldDate.getTime();
            const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
            
            for (let i = idx + 1; i < updated.length; i++) {
                const nextDate = new Date(updated[i].dueDate);
                nextDate.setDate(nextDate.getDate() + diffDays);
                updated[i].dueDate = nextDate.toISOString().split('T')[0];
            }
        }
    } else {
        updated[idx].amount = Number(value);
    }
    setDelayTrackingData(prev => ({ ...prev, installments: updated }));
  };

  useEffect(() => {
    if (!hasPermission('viewAllBookings') && userProfile && salesStaff.length > 0) {
      const linkedStaff = salesStaff.find(s => s.userId === userProfile.uid);
      if (linkedStaff) {
        setSelectedSalesId(linkedStaff.id);
      }
    }
  }, [salesStaff, userProfile, hasPermission]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // 1. Fetch all installment plans, bookings, customers, and sales staff
      const [p, b, c, s] = await Promise.all([
        genericGet<InstallmentPlan>('installment_plans'),
        genericGet<Booking>('bookings'),
        genericGet<Customer>('customers'),
        genericGet<SalesStaff>('sales_staff')
      ]);

      // 2. Filter active bookings and plans that have unpaid/un-cancelled installments
      const activeBookings = b.filter(bk => !bk.status || bk.status === 'ACTIVE' || (bk.status as string) === 'active');
      const activeBookingIds = new Set(activeBookings.map(item => item.id));

      const activePlans = p.filter(plan => {
        if (!activeBookingIds.has(plan.bookingId)) return false;
        return plan.installments && plan.installments.some(inst => inst.status !== 'paid' && inst.status !== 'cancelled');
      });

      setPlans(activePlans);
      setBookings(activeBookings);
      setCustomers(c);
      setSalesStaff(s);
    } catch (err) {
      console.error("Error fetching Installments data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { 
    fetchData(); 
    // Run silent auto-reconciliation in the background to repair any desynchronized records
    autoReconcileAllInstallmentPlans().then(res => {
      if (res.reconciledCount > 0) {
        fetchData();
      }
    }).catch(err => console.error("Background auto-reconciliation error:", err));
  }, []);

  const dueList = useMemo(() => {
    const todayStr = getCairoDateString();
    const soonDate = getCorrectDate(); soonDate.setDate(soonDate.getDate() + 3);
    const soonStr = getCairoDateString(soonDate);

    // Get linked staff for sales role filtering
    const linkedStaff = salesStaff.find(s => s.userId === userProfile?.uid);
    const canSeeAll = hasPermission('viewAllBookings');

    let items: DueListItem[] = [];

    plans.forEach(plan => {
      const booking = bookingsMap.get(plan.bookingId);
      if (!booking) return;
      if (booking.status && booking.status !== 'ACTIVE' && (booking.status as string) !== 'active') return;
      if (booking.paymentSummary && booking.paymentSummary.remaining <= 0) return;
      
      let customer = customersMap.get(booking.customerId);
      if (!customer) {
        // Fallback customer object so installments are NEVER hidden if customer document is missing
        customer = {
          id: booking.customerId || 'unknown',
          name: (booking as any).customerName || 'عميل غير معرف',
          phone: (booking as any).customerPhone || (booking as any).phone || '',
          whatsapp: (booking as any).customerPhone || (booking as any).phone || '',
          fullWhatsapp: (booking as any).customerPhone || (booking as any).phone || '',
          countryCode: '+20',
          email: (booking as any).email || ''
        };
      }

      // Privacy Filter: Sales staff only see their own bookings' installments
      if (!canSeeAll) {
        if (salesStaff.length > 0) {
          if (!linkedStaff || booking.salesId !== linkedStaff.id) return;
        }
      }

      plan.installments.forEach((inst, idx) => {
        if (inst.status === 'paid' || inst.status === 'cancelled') return;

        const nameMatches = searchQuery === '' ||
          customer!.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (customer!.whatsapp && customer!.whatsapp.includes(searchQuery)) ||
          (customer!.phone && customer!.phone.includes(searchQuery));

        if (!nameMatches) return;

        if (dateFilter.start && inst.dueDate < dateFilter.start) return;
        if (dateFilter.end && inst.dueDate > dateFilter.end) return;

        if (selectedSalesId !== 'all' && booking.salesId !== selectedSalesId) return;

        if (!dateFilter.start && !dateFilter.end) {
          const isToday = inst.dueDate === todayStr;
          const isSoon = inst.dueDate > todayStr && inst.dueDate <= soonStr;
          const isOverdue = inst.dueDate < todayStr;
          if (activeTab === 'today' && !isToday) return;
          if (activeTab === 'soon' && !isSoon) return;
          if (activeTab === 'overdue' && !isOverdue) return;
        }
        items.push({ plan, booking, customer: customer!, inst, index: idx });
      });
    });
    return items.sort((a, b) => a.inst.dueDate.localeCompare(b.inst.dueDate));
  }, [plans, bookingsMap, customersMap, activeTab, searchQuery, dateFilter, selectedSalesId, userProfile, salesStaff, hasPermission]);

  const filteredDueList = dueList; // Logic moved to dueList to avoid double filtering

  const unscheduledList = useMemo(() => {
    // Get linked staff for sales role filtering
    const linkedStaff = salesStaff.find(s => s.userId === userProfile?.uid);
    const canSeeAll = hasPermission('viewAllBookings');

    let items: UnscheduledItem[] = [];

    bookings.forEach(booking => {
      if (booking.isDeleted === true) return;
      if (booking.status && booking.status !== 'ACTIVE' && (booking.status as string) !== 'active') return;
      
      const remaining = booking.paymentSummary?.remaining ?? 0;
      if (remaining <= 0) return;

      const plan = plansMap.get(booking.id);
      
      // An installment plan is considered scheduled for remaining balance if it has at least 1 pending/delayed installment
      const activePendingInstallments = plan ? (plan.installments || []).filter(i => i.status === 'pending' || i.status === 'delayed') : [];
      
      // If there are pending installments, it is already scheduled in the regular pipeline
      if (activePendingInstallments.length > 0) return;

      // Otherwise, this active booking has remaining > 0 but NO scheduled pending installments!
      let customer = customersMap.get(booking.customerId);
      if (!customer) {
        customer = {
          id: booking.customerId || 'unknown',
          name: (booking as any).customerName || 'عميل غير معرف',
          phone: (booking as any).customerPhone || (booking as any).phone || '',
          whatsapp: (booking as any).customerPhone || (booking as any).phone || '',
          fullWhatsapp: (booking as any).customerPhone || (booking as any).phone || '',
          countryCode: '+20',
          email: (booking as any).email || ''
        };
      }

      // Privacy Filter: Sales staff only see their own bookings
      if (!canSeeAll) {
        if (salesStaff.length > 0) {
          if (!linkedStaff || booking.salesId !== linkedStaff.id) return;
        }
      }

      // Search Query
      const nameMatches = searchQuery === '' || 
        customer.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (customer.whatsapp && customer.whatsapp.includes(searchQuery)) ||
        (customer.phone && customer.phone.includes(searchQuery));
      if (!nameMatches) return;

      // Sales Filter
      if (selectedSalesId !== 'all' && booking.salesId !== selectedSalesId) return;

      const paidTotal = booking.paymentSummary?.paidTotal || 0;
      const finalPrice = booking.pricing?.finalPriceSnapshot || (paidTotal + remaining);

      items.push({
        booking,
        customer,
        plan,
        remainingAmount: remaining,
        paidTotal,
        finalPrice
      });
    });

    return items.sort((a, b) => b.remainingAmount - a.remainingAmount);
  }, [bookings, plansMap, customersMap, salesStaff, userProfile, hasPermission, searchQuery, selectedSalesId]);

  const groupedUnscheduledList = useMemo(() => {
    if (groupBy === 'none') return { 'All': unscheduledList } as Record<string, UnscheduledItem[]>;

    const groups: Record<string, UnscheduledItem[]> = {};
    unscheduledList.forEach(item => {
      let key = 'Other';
      if (groupBy === 'sales') {
        key = item.booking.salesName || 'Unknown Sales';
      } else {
        key = 'غير مجدولة';
      }
      if (!groups[key]) groups[key] = [];
      groups[key].push(item);
    });

    return groups;
  }, [unscheduledList, groupBy]);

  const groupedDueList = useMemo(() => {
    if (groupBy === 'none') return { 'All': filteredDueList } as Record<string, DueListItem[]>;

    const groups: Record<string, DueListItem[]> = {};
    filteredDueList.forEach(item => {
      let key = 'Other';
      if (groupBy === 'sales') {
        key = item.booking.salesName || 'Unknown Sales';
      } else if (groupBy === 'date') {
        key = item.inst.dueDate;
      }
      
      if (!groups[key]) groups[key] = [];
      groups[key].push(item);
    });

    // Sort keys if grouping by date
    if (groupBy === 'date') {
      return Object.keys(groups).sort().reduce((obj, key) => {
        obj[key] = groups[key];
        return obj;
      }, {} as Record<string, DueListItem[]>);
    }

    return groups;
  }, [filteredDueList, groupBy]);

  const handlePay = async () => {
    if (!paymentModal) return;
    const { planId, index, amount } = paymentModal;
    const booking = bookings.find(b => b.id === planId);
    if (!booking) return;
    
    // Check if overdue and reason is missing
    const plan = plans.find(p => p.bookingId === planId);
    if (plan && plan.installments[index]) {
      const inst = plan.installments[index];
      const todayStr = getCairoDateString();
      if (inst.dueDate < todayStr && !paymentData.note.trim()) {
        alert("هذا القسط متأخر، يجب ذكر السبب في الملاحظات");
        return;
      }
    }

    setIsProcessing(true);
    try {
        await addPaymentAndUpdateBooking({ 
          bookingId: planId, 
          customerId: booking.customerId, 
          groupId: booking.groupId, 
          paymentDate: getCairoDateString(), 
          amount, 
          method: paymentData.method, 
          transactionRef: paymentData.ref, 
          receiptLink: paymentData.receiptLink,
          note: paymentData.note || 'Installment Payment', 
          createdByUid: userProfile?.uid || '' 
        }, index, { name: userProfile?.displayName || 'Unknown', email: userProfile?.email || 'Unknown' });
        setPaymentModal(null); setPaymentData({ method: 'cash_office', ref: '', note: '', receiptLink: '' }); fetchData();
    } catch(e) { console.error(e); } finally { setIsProcessing(false); }
  };

  const handleReschedule = async () => {
      if (!delayModal) return;
      if (!delayData.reason.trim()) {
        alert("يجب كتابة سبب إعادة الجدولة أو التأجيل");
        return;
      }
      setIsProcessing(true);
      try {
          await rescheduleRemainingInstallments(delayModal.planId, reschedulePlan.length, '', delayData.reason, reschedulePlan, { name: userProfile?.displayName || 'Unknown', email: userProfile?.email || 'Unknown' });
          setDelayModal(null); fetchData();
      } catch(err: any) { alert("Error: " + err.message); } finally { setIsProcessing(false); }
  };

  const handleUpdateCount = (count: number) => {
      if (!delayModal || count < 1) return;
      const remainingBalance = delayModal.booking.paymentSummary.remaining;
      // Split with floor division and give the rounding remainder to the LAST installment,
      // so the installments always sum exactly to remainingBalance (plain division left
      // fractional pounds and a permanent gap vs. the real remaining balance).
      const baseAmount = Math.floor(remainingBalance / count);
      const remainder = remainingBalance - (baseAmount * count);
      const originalPlan = plans.find(p => p.bookingId === delayModal.planId);
      const type = originalPlan?.installmentType || 'monthly';
      const firstDate = reschedulePlan[0]?.dueDate || getCairoDateString();

      const newList: Installment[] = [];
      for(let i=0; i<count; i++) {
          const d = new Date(firstDate);
          if (useUniformInterval) {
              d.setDate(d.getDate() + (i * uniformDays));
          } else {
              if (type === 'weekly') d.setDate(d.getDate() + (i * 7));
              else d.setMonth(d.getMonth() + i);
          }
          const isLast = i === count - 1;
          newList.push({
              dueDate: d.toISOString().split('T')[0],
              amount: isLast ? baseAmount + remainder : baseAmount,
              status: 'pending',
              notifiedOnWhatsApp: false
          });
      }
      setReschedulePlan(newList);
      setDelayData(prev => ({ ...prev, newCount: count }));
  };

  const handleLocalEdit = (idx: number, field: 'dueDate' | 'amount', value: any) => {
    const updated = [...reschedulePlan];
    if (!updated[idx]) return;

    if (field === 'dueDate') {
        const oldDate = new Date(updated[idx].dueDate);
        const newDate = new Date(value);
        
        // تحديث تاريخ القسط الحالي
        updated[idx].dueDate = value;

        if (useUniformInterval) {
            // ترحيل بناءً على فواصل زمنية ثابتة (Uniform Intervals)
            for (let i = idx + 1; i < updated.length; i++) {
                const prevDate = new Date(updated[i-1].dueDate);
                prevDate.setDate(prevDate.getDate() + uniformDays);
                updated[i].dueDate = prevDate.toISOString().split('T')[0];
            }
        } else {
            // ترحيل بناءً على فارق الأيام (Smart Shift / Delta)
            const diffTime = newDate.getTime() - oldDate.getTime();
            const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
            
            for (let i = idx + 1; i < updated.length; i++) {
                const nextDate = new Date(updated[i].dueDate);
                nextDate.setDate(nextDate.getDate() + diffDays);
                updated[i].dueDate = nextDate.toISOString().split('T')[0];
            }
        }
    } else {
        updated[idx].amount = Number(value);
    }
    setReschedulePlan(updated);
  };

  const statsForDelay = useMemo(() => {
      if (!delayModal) return null;
      const plan = plans.find(p => p.bookingId === delayModal.planId);
      const remaining = delayModal.booking.paymentSummary?.remaining ?? 0;
      
      const paid = plan ? (plan.installments || []).filter(i => i.status === 'paid').length : 0;
      const pendingList = plan ? (plan.installments || []).filter(i => i.status === 'pending' || i.status === 'delayed') : [];
      
      if (pendingList.length === 0) {
        const agreement = delayModal.booking.unscheduledAgreement;
        const initialStartDate = agreement?.agreedDate || getCairoDateString();
        const initialCount = Math.max(1, agreement?.suggestedCount || 1);
        const perInst = remaining / initialCount;

        const initialList: Installment[] = [];
        for (let i = 0; i < initialCount; i++) {
          const d = new Date(initialStartDate);
          d.setMonth(d.getMonth() + i);
          initialList.push({
            dueDate: d.toISOString().split('T')[0],
            amount: perInst,
            status: 'pending',
            notifiedOnWhatsApp: false
          });
        }

        return { 
          paid, 
          pending: initialCount, 
          remaining, 
          pendingList: initialList 
        };
      }

      return { paid, pending: pendingList.length, remaining, pendingList };
  }, [delayModal, plans]);

  useEffect(() => {
    if (statsForDelay?.pendingList) {
        setReschedulePlan(statsForDelay.pendingList);
        const agreement = delayModal?.booking.unscheduledAgreement;
        const defaultReason = agreement?.agreementNote 
          ? `جدولة متبقيات الحجز وفقاً للاتفاق: ${agreement.agreementNote}` 
          : 'جدولة متبقيات الحجز';
        setDelayData(prev => ({ ...prev, newCount: statsForDelay.pending, reason: prev.reason || defaultReason }));
    }
  }, [statsForDelay, delayModal]);

  return (
    <div>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-bold">{t('installments')} / Collections</h1>
          <p className="text-xs text-gray-500 font-medium mt-1">
            {lang === 'ar' ? 'متابعة وتحصيل الأقساط المستحقة والمتأخرة بدقة متناهية' : 'Monitor and collect due and overdue installments accurately'}
          </p>
        </div>
        <button
          onClick={handleReconcileAll}
          disabled={isReconciling}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-primary-600 hover:bg-primary-700 active:scale-95 text-white font-bold text-xs rounded-2xl shadow-sm transition-all disabled:opacity-50 cursor-pointer w-fit"
          title={lang === 'ar' ? 'فحص ومزامنة جميع خطط الأقساط وإصلاح أي فروق مع المدفوعات الفعلية' : 'Reconcile and sync all installment plans with actual payments'}
        >
          <i className={`fas ${isReconciling ? 'fa-spinner fa-spin' : 'fa-wand-magic-sparkles'}`}></i>
          <span>
            {isReconciling 
              ? (lang === 'ar' ? 'جاري الفحص والمزامنة...' : 'Reconciling...') 
              : (lang === 'ar' ? '⚡ فحص ومزامنة خطط الأقساط' : '⚡ Reconcile & Sync All Plans')}
          </span>
        </button>
      </div>

      {/* Sales Installment Summary Cards */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-2.5 h-6 bg-primary-500 rounded-full"></div>
          <h2 className="text-lg font-black dark:text-white">
            {lang === 'ar' ? '📊 ملخص الأقساط ومتابعة السيلز' : '📊 Sales Installments Performance Summary'}
          </h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {salesStats.length === 0 ? (
            <div className="col-span-full p-6 text-center text-gray-400 bg-white dark:bg-gray-800 rounded-3xl border border-dashed border-gray-100 dark:border-gray-700">
              {lang === 'ar' ? 'لا توجد أقساط مستحقة اليوم أو متأخرة حالياً.' : 'No due or overdue installments currently.'}
            </div>
          ) : (
            salesStats.map(stat => (
              <div key={stat.salesId} className="bg-white dark:bg-gray-800 rounded-3xl border border-gray-100 dark:border-gray-700 shadow-sm p-6 hover:shadow-md transition-shadow relative overflow-hidden flex flex-col justify-between">
                
                {/* Header */}
                <div className="flex items-center justify-between mb-4 border-b border-gray-50 dark:border-gray-700/50 pb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-full bg-primary-50 dark:bg-primary-900/20 text-primary-600 flex items-center justify-center font-bold text-sm">
                      <i className="fas fa-user-tie"></i>
                    </div>
                    <div>
                      <h3 className="font-extrabold text-gray-800 dark:text-gray-100 text-sm md:text-base">{stat.salesName}</h3>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">{lang === 'ar' ? 'مسؤول المبيعات' : 'Sales Representative'}</p>
                    </div>
                  </div>
                  
                  {/* Quick Badge */}
                  {(stat.overdueClientsCount > 0 || stat.unscheduledClientsCount > 0) && (
                    <span className={`text-[10px] font-black px-2.5 py-1 rounded-full border ${
                      stat.overdueClientsCount > 0 
                        ? 'bg-red-50 dark:bg-red-950/30 text-red-600 dark:text-red-400 border-red-100 dark:border-red-900/30 animate-pulse'
                        : 'bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 border-amber-100 dark:border-amber-900/30'
                    }`}>
                      {stat.overdueClientsCount > 0 ? (lang === 'ar' ? 'تنبيه تأخير' : 'Overdue Alert') : (lang === 'ar' ? 'متبقيات تحتاج جدولة' : 'Needs Scheduling')}
                    </span>
                  )}
                </div>

                {/* Stats Sections */}
                <div className="grid grid-cols-3 gap-2.5">
                  
                  {/* Overdue (المتأخرات) */}
                  <div className="bg-red-50/40 dark:bg-red-950/10 rounded-2xl p-3 border border-red-100/30 dark:border-red-950/20 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1 text-red-600 dark:text-red-400 font-extrabold text-[10px] mb-1.5">
                        <i className="fas fa-exclamation-circle text-[10px]"></i>
                        <span className="truncate">{lang === 'ar' ? 'متأخرات' : 'Overdue'}</span>
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-[11px] text-gray-500 dark:text-gray-400 font-medium">
                          {lang === 'ar' ? 'عملاء: ' : 'Clients: '}
                          <strong className="text-red-600 dark:text-red-400 font-black">{stat.overdueClientsCount}</strong>
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-red-100/30 dark:border-red-950/20">
                      <p className="text-[9px] text-gray-400 font-bold uppercase mb-0.5">{lang === 'ar' ? 'المبلغ' : 'Amount'}</p>
                      <p className="text-xs font-black text-red-600 dark:text-red-400 truncate">{stat.overdueTotalAmount.toLocaleString()} ج.م</p>
                    </div>
                  </div>

                  {/* Today (مستحق اليوم) */}
                  <div className="bg-emerald-50/40 dark:bg-emerald-950/10 rounded-2xl p-3 border border-emerald-100/30 dark:border-emerald-950/20 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-extrabold text-[10px] mb-1.5">
                        <i className="fas fa-calendar-check text-[10px]"></i>
                        <span className="truncate">{lang === 'ar' ? 'اليوم' : 'Today'}</span>
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-[11px] text-gray-500 dark:text-gray-400 font-medium">
                          {lang === 'ar' ? 'عملاء: ' : 'Clients: '}
                          <strong className="text-emerald-600 dark:text-emerald-400 font-black">{stat.todayClientsCount}</strong>
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-emerald-100/30 dark:border-emerald-950/20">
                      <p className="text-[9px] text-gray-400 font-bold uppercase mb-0.5">{lang === 'ar' ? 'المبلغ' : 'Amount'}</p>
                      <p className="text-xs font-black text-emerald-600 dark:text-emerald-400 truncate">{stat.todayTotalAmount.toLocaleString()} ج.م</p>
                    </div>
                  </div>

                  {/* Unscheduled (غير مجدول) */}
                  <div className="bg-amber-50/40 dark:bg-amber-950/10 rounded-2xl p-3 border border-amber-100/30 dark:border-amber-950/20 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1 text-amber-600 dark:text-amber-400 font-extrabold text-[10px] mb-1.5">
                        <i className="fas fa-calendar-times text-[10px]"></i>
                        <span className="truncate">{lang === 'ar' ? 'غير مجدول' : 'Unscheduled'}</span>
                      </div>
                      <div className="space-y-0.5">
                        <p className="text-[11px] text-gray-500 dark:text-gray-400 font-medium">
                          {lang === 'ar' ? 'عملاء: ' : 'Clients: '}
                          <strong className="text-amber-600 dark:text-amber-400 font-black">{stat.unscheduledClientsCount}</strong>
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 pt-1.5 border-t border-amber-100/30 dark:border-amber-950/20">
                      <p className="text-[9px] text-gray-400 font-bold uppercase mb-0.5">{lang === 'ar' ? 'المبلغ' : 'Amount'}</p>
                      <p className="text-xs font-black text-amber-600 dark:text-amber-400 truncate">{stat.unscheduledTotalAmount.toLocaleString()} ج.م</p>
                    </div>
                  </div>

                </div>
                
              </div>
            ))
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-8 bg-white dark:bg-gray-800 p-6 rounded-3xl shadow-sm border border-gray-100 dark:border-gray-700 items-end">
        <div className="lg:col-span-1">
          <label className="block text-[10px] font-black text-gray-400 mb-2 uppercase tracking-widest">Search Trainee</label>
          <div className="relative">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input type="text" placeholder="Enter name or WhatsApp..." className="w-full pl-12 pr-4 py-3 bg-gray-50 dark:bg-gray-700 rounded-2xl outline-none font-medium text-sm" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
          </div>
        </div>
        <div>
          <label className="block text-[10px] font-black text-gray-400 mb-2 uppercase tracking-widest">Sales Representative</label>
          <select 
            className={`w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-sm font-bold ${!hasPermission('viewAllBookings') ? 'opacity-50 cursor-not-allowed' : ''}`}
            value={selectedSalesId} 
            onChange={e => setSelectedSalesId(e.target.value)}
            disabled={!hasPermission('viewAllBookings')}
          >
            {hasPermission('viewAllBookings') && <option value="all">All Sales</option>}
            {salesStaff.filter(s => s.isActive).filter(s => {
              if (hasPermission('viewAllBookings')) return true;
              return s.userId === userProfile?.uid;
            }).map(s => (
              <option key={s.id} value={s.id}>{s.fullName}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-black text-gray-400 mb-2 uppercase tracking-widest">Due From</label>
          <input type="date" className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-sm" value={dateFilter.start} onChange={e => setDateFilter({...dateFilter, start: e.target.value})} />
        </div>
        <div>
          <label className="block text-[10px] font-black text-gray-400 mb-2 uppercase tracking-widest">Due To</label>
          <input type="date" className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-sm" value={dateFilter.end} onChange={e => setDateFilter({...dateFilter, end: e.target.value})} />
        </div>
        <div>
          <label className="block text-[10px] font-black text-gray-400 mb-2 uppercase tracking-widest">Group By</label>
          <select 
            className="w-full p-3 bg-primary-50 dark:bg-primary-900/20 text-primary-600 rounded-xl outline-none text-sm font-bold border border-primary-100" 
            value={groupBy} 
            onChange={e => setGroupBy(e.target.value as any)}
          >
            <option value="none">No Grouping</option>
            <option value="sales">Sales Representative</option>
            <option value="date">Due Date</option>
          </select>
        </div>
      </div>

      {!dateFilter.start && !dateFilter.end && (
        <div className="flex flex-wrap gap-2 mb-8 p-1.5 bg-gray-100 dark:bg-gray-800 rounded-2xl w-fit">
          {[
            { key: 'today' as const, label: t('dueToday'), badge: undefined as number | undefined },
            { key: 'soon' as const, label: t('dueSoon'), badge: undefined as number | undefined },
            { key: 'overdue' as const, label: t('Overdue'), badge: undefined as number | undefined },
            { 
              key: 'unscheduled' as const, 
              label: lang === 'ar' ? 'متبقيات غير مجدولة' : 'Unscheduled Balances',
              badge: unscheduledList.length > 0 ? unscheduledList.length : undefined
            },
            { key: 'all' as const, label: t('allUpcoming'), badge: undefined as number | undefined }
          ].map(tab => (
            <button 
              key={tab.key} 
              onClick={() => setActiveTab(tab.key)} 
              className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
                activeTab === tab.key 
                  ? 'bg-white dark:bg-gray-700 shadow-sm text-primary-600' 
                  : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                  activeTab === tab.key
                    ? 'bg-amber-500 text-white'
                    : 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300'
                }`}>
                  {tab.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      )}

      {/* Main Content Area */}
      {activeTab === 'unscheduled' ? (
        <div className="space-y-6">
          {/* Informative Banner */}
          <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-3xl p-5 flex items-start gap-4">
            <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 font-bold text-lg shadow-sm">
              <i className="fas fa-calendar-times"></i>
            </div>
            <div>
              <h3 className="font-bold text-amber-900 dark:text-amber-200 text-sm md:text-base mb-1">
                {lang === 'ar' ? 'حجوزات نشطة عليها متبقي مالي بدون جدول أقساط' : 'Active bookings with remaining balances but no scheduled installment plan'}
              </h3>
              <p className="text-xs text-amber-700 dark:text-amber-400/90 leading-relaxed">
                {lang === 'ar' 
                  ? 'هؤلاء العملاء لديهم مبالغ متبقية مستحقة على النظام، ولكن لم يتم تحديد مواعيد أو خطة أقساط لهم. يمكنك الضغط على "جدولة الأقساط" لتحديد التواريخ وعدد الأقساط، أو "تحصيل الآن" لتسجيل دفعة فورية.'
                  : 'These trainees have outstanding remaining balances, but lack scheduled installment dates. Click "Schedule Plan" to set dates and installments, or "Pay Balance" to record a payment.'}
              </p>
            </div>
          </div>

          <div className="space-y-8">
            {(Object.entries(groupedUnscheduledList) as [string, UnscheduledItem[]][]).map(([groupName, items]) => (
              <div key={groupName}>
                {groupBy !== 'none' && (
                  <div className="flex items-center gap-4 mb-4">
                    <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700"></div>
                    <h2 className="text-xs font-black uppercase tracking-[0.2em] text-gray-400 bg-gray-50 dark:bg-gray-800 px-4 py-1 rounded-full border dark:border-gray-700">
                      {groupBy === 'sales' ? <i className="fas fa-user-tie mr-2"></i> : <i className="fas fa-layer-group mr-2"></i>}
                      {groupName} ({items.length})
                    </h2>
                    <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700"></div>
                  </div>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {items.map((item) => (
                    <UnscheduledCard 
                      key={item.booking.id}
                      item={item}
                      userProfile={userProfile}
                      hasPermission={hasPermission}
                      onPay={(bid, amt) => setPaymentModal({ planId: bid, index: 0, amount: amt })}
                      onReschedule={(bid, b) => setDelayModal({ planId: bid, index: 0, booking: b })}
                      onViewHistory={(b) => {
                        setActiveHistoryBooking(b);
                        setHistoryModalOpen(true);
                      }}
                      onInspect={(b, c, p) => setStudentBookingModal({ booking: b, customer: c, plan: p })}
                      onSaveAgreement={handleSaveUnscheduledAgreement}
                    />
                  ))}
                </div>
              </div>
            ))}
            {unscheduledList.length === 0 && !loading && (
              <div className="py-20 text-center bg-white dark:bg-gray-800 rounded-3xl border border-dashed border-gray-100 dark:border-gray-700 p-8">
                <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                  <i className="fas fa-check-double"></i>
                </div>
                <h3 className="font-bold text-gray-800 dark:text-gray-200 text-base mb-1">
                  {lang === 'ar' ? 'رائع! لا توجد أي متبقيات غير مجدولة' : 'All remaining balances are scheduled!'}
                </h3>
                <p className="text-xs text-gray-400 max-w-md mx-auto">
                  {lang === 'ar' 
                    ? 'جميع العملاء الذين عليهم مبالغ متبقية لديهم خطط وتواريخ أقساط مجدولة ومنتظمة.'
                    : 'All bookings with remaining balances have active installment plans with scheduled dates.'}
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          {(Object.entries(groupedDueList) as [string, DueListItem[]][]).map(([groupName, items]) => (
            <div key={groupName}>
              {groupBy !== 'none' && (
                <div className="flex items-center gap-4 mb-4">
                  <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700"></div>
                  <h2 className="text-xs font-black uppercase tracking-[0.2em] text-gray-400 bg-gray-50 dark:bg-gray-800 px-4 py-1 rounded-full border dark:border-gray-700">
                    {groupBy === 'sales' ? <i className="fas fa-user-tie mr-2"></i> : <i className="fas fa-calendar-alt mr-2"></i>}
                    {groupName} ({items.length})
                  </h2>
                  <div className="h-px flex-1 bg-gray-200 dark:bg-gray-700"></div>
                </div>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {items.map((item) => (
                  <InstallmentCard 
                    key={`${item.plan.bookingId}-${item.index}`}
                    item={item}
                    userProfile={userProfile}
                    hasPermission={hasPermission}
                    onMarkNotified={handleMarkNotified}
                    onToggleDelayContacted={handleToggleDelayContacted}
                    onPay={(pid, idx, amt) => setPaymentModal({ planId: pid, index: idx, amount: amt })}
                    onReschedule={(pid, idx, b) => setDelayModal({ planId: pid, index: idx, booking: b })}
                    onUpdateDelayTracking={(i) => {
                      const fullPlan = plans.find(p => p.bookingId === i.plan.bookingId);
                      setDelayTrackingModal({ planId: i.plan.bookingId, index: i.index, inst: i.inst, booking: i.booking });
                      setDelayTrackingData({ 
                        reason: i.inst.delayReason || i.inst.rescheduleReason || '', 
                        newDate: i.inst.dueDate,
                        installments: fullPlan?.installments || []
                      });
                    }}
                    toggleSalesReminder={handleToggleSalesReminder}
                    toggleSupervisorVerify={handleToggleSupervisorVerify}
                    onAddNote={(pid, idx) => {
                      const noteText = prompt("Add a note to this installment:");
                      if (noteText && userProfile) {
                        const addNoteHandler = async () => {
                           await addInstallmentNote(pid, idx, { text: noteText, uid: userProfile.uid, name: userProfile.displayName });
                           fetchData();
                        };
                        addNoteHandler();
                      }
                    }}
                    onViewHistory={(b) => {
                      setActiveHistoryBooking(b);
                      setHistoryModalOpen(true);
                    }}
                    onInspect={(b, c, p) => setStudentBookingModal({ booking: b, customer: c, plan: p })}
                  />
                ))}
              </div>
            </div>
          ))}
          {filteredDueList.length === 0 && !loading && <div className="py-20 text-center text-gray-400 italic font-medium">No results matching your filters.</div>}
        </div>
      )}

      {/* Enhanced Reschedule Modal */}
      {delayModal && statsForDelay && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 overflow-y-auto">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
                <h2 className="text-2xl font-black uppercase tracking-tight">إعادة جدولة الأقساط</h2>
                <button onClick={() => setDelayModal(null)} className="text-gray-400 hover:text-red-500"><i className="fas fa-times text-xl"></i></button>
            </div>
            
            <div className="grid grid-cols-3 gap-3 mb-6 bg-gray-50 dark:bg-gray-700/50 p-4 rounded-2xl border dark:border-gray-600">
                <div className="text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">إجمالي المتبقي</p>
                    <p className="text-sm font-bold text-red-500">{statsForDelay.remaining.toLocaleString()} ج.م</p>
                </div>
                <div className="text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">أقساط مدفوعة</p>
                    <p className="text-sm font-bold text-green-600">{statsForDelay.paid}</p>
                </div>
                <div className="text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">أقساط متبقية</p>
                    <p className="text-sm font-bold text-primary-600">{statsForDelay.pending}</p>
                </div>
            </div>

            {/* Smart Intervals Option */}
            <div className="bg-amber-50 dark:bg-amber-900/10 p-5 rounded-[1.5rem] mb-6 border border-amber-200 dark:border-amber-900/50">
                <div className="flex items-center justify-between mb-3">
                    <label className="flex items-center space-x-3 rtl:space-x-reverse cursor-pointer">
                        <input 
                            type="checkbox" 
                            checked={useUniformInterval} 
                            onChange={e => setUseUniformInterval(e.target.checked)} 
                            className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500" 
                        />
                        <span className="text-xs font-black text-amber-700 uppercase">تفعيل فواصل زمنية ثابتة</span>
                    </label>
                    {useUniformInterval && (
                        <span className="text-[9px] font-bold text-amber-600 bg-white px-2 py-1 rounded-full shadow-sm">ترحيل بناءً على عدد الأيام</span>
                    )}
                </div>
                {useUniformInterval && (
                    <div className="flex items-center gap-3">
                        <span className="text-[10px] font-bold text-amber-600 w-24">عدد الأيام الفاصلة:</span>
                        <input 
                            type="number" 
                            className="flex-1 p-2 bg-white dark:bg-gray-800 rounded-lg outline-none text-xs font-black" 
                            value={uniformDays} 
                            onChange={e => setUniformDays(Number(e.target.value))} 
                        />
                    </div>
                )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase block mb-1">تعديل عدد الأقساط المتبقية</label>
                    <input 
                        type="number" 
                        min="1" 
                        className="w-full p-3 bg-primary-50 dark:bg-primary-900/20 text-primary-600 font-bold rounded-xl outline-none border border-primary-100" 
                        value={delayData.newCount} 
                        onChange={e => handleUpdateCount(Number(e.target.value))} 
                    />
                </div>
                <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase block mb-1">سبب التعديل / التأجيل</label>
                    <input 
                        type="text" 
                        className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-sm" 
                        value={delayData.reason} 
                        onChange={e => setDelayData({...delayData, reason: e.target.value})} 
                        placeholder="اختياري..."
                    />
                </div>
            </div>

            <div className="space-y-3 mb-8">
                <div className="flex justify-between items-center mb-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">قائمة الأقساط (تعديل التاريخ يرحل ما بعده تلقائياً)</label>
                    <span className={`text-[9px] font-bold px-2 py-0.5 rounded italic ${useUniformInterval ? 'text-amber-600 bg-amber-50' : 'text-primary-600 bg-primary-50'}`}>
                        {useUniformInterval ? 'Fixed Interval Mode' : 'Smart Delta Mode'}
                    </span>
                </div>
                <div className="max-h-60 overflow-y-auto space-y-2 pr-2 custom-scrollbar border-y dark:border-gray-700 py-4">
                    {reschedulePlan.map((inst, idx) => (
                        <div key={idx} className="flex items-center gap-3 bg-gray-50 dark:bg-gray-700/50 p-3 rounded-xl border dark:border-gray-600 hover:border-primary-300 transition-all">
                            <span className="w-8 text-[10px] font-black text-gray-400 text-center">#{idx+1}</span>
                            <div className="flex-1">
                                <input 
                                    type="date" 
                                    className="w-full p-2 bg-white dark:bg-gray-800 rounded-lg text-xs outline-none focus:ring-2 focus:ring-primary-500" 
                                    value={inst.dueDate} 
                                    onChange={e => handleLocalEdit(idx, 'dueDate', e.target.value)} 
                                />
                            </div>
                            <div className="w-28">
                                <input 
                                    type="number" 
                                    className="w-full p-2 bg-white dark:bg-gray-800 rounded-lg text-xs outline-none font-bold text-center" 
                                    value={inst.amount} 
                                    onChange={e => handleLocalEdit(idx, 'amount', e.target.value)} 
                                />
                            </div>
                        </div>
                    ))}
                </div>
                <div className="flex justify-between text-[10px] font-bold text-gray-400 px-2">
                    <span>إجمالي الخطة:</span>
                    <span className={Math.abs(reschedulePlan.reduce((s,i)=>s+i.amount,0) - statsForDelay.remaining) < 1 ? 'text-green-600' : 'text-red-500'}>
                        {reschedulePlan.reduce((s,i)=>s+i.amount,0).toLocaleString()} / {statsForDelay.remaining.toLocaleString()} ج.م
                    </span>
                </div>
            </div>

            <div className="flex flex-col gap-2">
                <button 
                    onClick={handleReschedule} 
                    disabled={isProcessing || Math.abs(reschedulePlan.reduce((s,i)=>s+i.amount,0) - statsForDelay.remaining) > 1} 
                    className="w-full py-4 bg-primary-600 text-white rounded-2xl font-black shadow-lg shadow-primary-500/20 uppercase tracking-widest disabled:opacity-30 disabled:cursor-not-allowed transform active:scale-95 transition-all"
                >
                    {isProcessing ? 'جاري الحفظ...' : 'حفظ وإعادة الجدولة الذكية'}
                </button>
            </div>
          </div>
        </div>
      )}

      {/* Delay Tracking Modal */}
      {delayTrackingModal && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 overflow-y-auto">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-start mb-6">
              <h2 className="text-xl font-black uppercase tracking-tight">متابعة تأخير القسط</h2>
              <button onClick={() => setDelayTrackingModal(null)} className="text-gray-400 hover:text-red-500"><i className="fas fa-times text-xl"></i></button>
            </div>
            
            <div className="grid grid-cols-3 gap-3 mb-6 bg-gray-50 dark:bg-gray-700/50 p-4 rounded-2xl border dark:border-gray-600">
                <div className="text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">إجمالي المتبقي</p>
                    <p className="text-sm font-bold text-red-500">{delayTrackingModal.booking.paymentSummary.remaining.toLocaleString()} ج.م</p>
                </div>
                <div className="text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">أقساط مدفوعة</p>
                    <p className="text-sm font-bold text-green-600">{delayTrackingData.installments.filter(i => i.status === 'paid').length}</p>
                </div>
                <div className="text-center">
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">أقساط متبقية</p>
                    <p className="text-sm font-bold text-primary-600">{delayTrackingData.installments.filter(i => i.status !== 'paid' && i.status !== 'cancelled').length}</p>
                </div>
            </div>

            <div className="space-y-4">
              <div className="bg-amber-50 dark:bg-amber-900/10 p-5 rounded-[1.5rem] border border-amber-200 dark:border-amber-900/50">
                <div className="flex items-center justify-between mb-3">
                    <label className="flex items-center space-x-3 rtl:space-x-reverse cursor-pointer">
                        <input 
                            type="checkbox" 
                            checked={useUniformInterval} 
                            onChange={e => setUseUniformInterval(e.target.checked)} 
                            className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500" 
                        />
                        <span className="text-xs font-black text-amber-700 uppercase">تفعيل فواصل زمنية ثابتة</span>
                    </label>
                </div>
                {useUniformInterval && (
                    <div className="flex items-center gap-3">
                        <span className="text-[10px] font-bold text-amber-600 w-24">عدد الأيام الفاصلة:</span>
                        <input 
                            type="number" 
                            className="flex-1 p-2 bg-white dark:bg-gray-800 rounded-lg outline-none text-xs font-black" 
                            value={uniformDays} 
                            onChange={e => setUniformDays(Number(e.target.value))} 
                        />
                    </div>
                )}
              </div>

              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase block mb-1">سبب التأخير / ما تم الاتفاق عليه</label>
                <textarea 
                  className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none text-sm min-h-[80px] resize-none border border-transparent focus:border-amber-500" 
                  value={delayTrackingData.reason} 
                  onChange={e => setDelayTrackingData({...delayTrackingData, reason: e.target.value})} 
                  placeholder="اكتب هنا تفاصيل التواصل مع العميل..."
                />
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center mb-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">قائمة الأقساط (تعديل التاريخ يرحل ما بعده تلقائياً)</label>
                </div>
                <div className="max-h-60 overflow-y-auto space-y-2 pr-2 custom-scrollbar border-y dark:border-gray-700 py-4">
                    {delayTrackingData.installments.map((inst, idx) => (
                        <div key={idx} className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${idx === delayTrackingModal.index ? 'bg-amber-50 border-amber-300 dark:bg-amber-900/20' : 'bg-gray-50 dark:bg-gray-700/50 border-transparent dark:border-gray-600'}`}>
                            <span className="w-8 text-[10px] font-black text-gray-400 text-center">#{idx+1}</span>
                            <div className="flex-1">
                                <input 
                                    type="date" 
                                    className={`w-full p-2 rounded-lg text-xs outline-none focus:ring-2 focus:ring-amber-500 ${inst.status === 'paid' ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white dark:bg-gray-800'}`} 
                                    value={inst.dueDate} 
                                    onChange={e => handleDelayTrackingLocalEdit(idx, 'dueDate', e.target.value)} 
                                    disabled={inst.status === 'paid'}
                                />
                            </div>
                            <div className="w-28">
                                <input 
                                    type="number" 
                                    className={`w-full p-2 rounded-lg text-xs outline-none font-bold text-center ${inst.status === 'paid' ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-white dark:bg-gray-800'}`} 
                                    value={inst.amount} 
                                    onChange={e => handleDelayTrackingLocalEdit(idx, 'amount', e.target.value)} 
                                    disabled={inst.status === 'paid'}
                                />
                            </div>
                            <div className="w-16 text-center">
                                <span className={`text-[8px] font-black uppercase px-1.5 py-0.5 rounded ${inst.status === 'paid' ? 'bg-green-100 text-green-600' : inst.status === 'delayed' ? 'bg-amber-100 text-amber-600' : 'bg-gray-100 text-gray-500'}`}>
                                    {inst.status}
                                </span>
                            </div>
                        </div>
                    ))}
                </div>
              </div>
              
              <div className="flex justify-end space-x-3 pt-6 rtl:space-x-reverse">
                <button 
                  onClick={() => setDelayTrackingModal(null)} 
                  className="px-6 py-2 font-bold text-gray-400" 
                  disabled={isProcessing}
                >
                  إلغاء
                </button>
                <button 
                  onClick={handleUpdateDelayTracking} 
                  className="px-8 py-3 bg-amber-600 text-white rounded-xl font-black shadow-lg shadow-amber-500/20 disabled:opacity-50" 
                  disabled={isProcessing || !delayTrackingData.reason}
                >
                  {isProcessing ? 'جاري الحفظ...' : 'حفظ البيانات'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      {paymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-2xl w-full max-w-md">
            <h2 className="text-xl font-bold mb-6">تحصيل قسط</h2>
            <div className="space-y-4">
              <input type="number" className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none font-bold text-lg" value={paymentModal.amount} readOnly />
              <select className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none border-2 border-transparent focus:border-primary-500 font-medium" value={paymentData.method} onChange={e => setPaymentData({...paymentData, method: e.target.value as any})}><option value="cash_office">Office Cash</option><option value="vodafone_cash">Vodafone Cash</option><option value="instapay">InstaPay</option><option value="etisalat_cash">Etisalat Cash</option><option value="paypal">PayPal</option></select>
              <input type="text" placeholder="رقم المرجع..." className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none" value={paymentData.ref} onChange={e => setPaymentData({...paymentData, ref: e.target.value})} />
              <input type="text" placeholder="رابط الإيصال (اختياري)..." className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none" value={paymentData.receiptLink} onChange={e => setPaymentData({...paymentData, receiptLink: e.target.value})} />
              <textarea placeholder="ملاحظات / سبب التأخير (إلزامي في حالة التأخير)..." className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none min-h-[80px]" value={paymentData.note} onChange={e => setPaymentData({...paymentData, note: e.target.value})} />
              <div className="flex justify-end space-x-3 pt-6"><button onClick={() => setPaymentModal(null)} className="px-6 py-2 font-bold text-gray-400" disabled={isProcessing}>إلغاء</button><button onClick={handlePay} className="px-8 py-3 bg-green-600 text-white rounded-xl font-black shadow-lg shadow-green-500/20" disabled={isProcessing}>{isProcessing ? 'جاري...' : 'تأكيد التحصيل'}</button></div>
            </div>
          </div>
        </div>
      )}

      <HistoryModal 
        isOpen={isHistoryModalOpen} 
        onClose={() => setHistoryModalOpen(false)} 
        booking={activeHistoryBooking} 
        customers={customers} 
        onDataChanged={fetchData}
      />

      <StudentBookingDetailsModal
        isOpen={!!studentBookingModal}
        onClose={() => setStudentBookingModal(null)}
        booking={studentBookingModal?.booking || null}
        customer={studentBookingModal?.customer || null}
        plan={studentBookingModal?.plan}
        onPay={(bid, amt) => setPaymentModal({ planId: bid, index: 0, amount: amt })}
        onReschedule={(bid, b) => setDelayModal({ planId: bid, index: 0, booking: b })}
        onDataChanged={fetchData}
      />
    </div>
  );
};

export default Installments;
