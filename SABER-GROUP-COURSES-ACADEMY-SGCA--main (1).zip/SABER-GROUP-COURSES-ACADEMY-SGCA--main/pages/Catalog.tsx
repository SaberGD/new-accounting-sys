import React, { useState, useEffect } from 'react';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { genericGet, genericAdd, genericUpdate, genericDelete, auditAndEnforceHistoricalBookingPrices, PriceAuditResult } from '../services/firestore';
import { buildUpdatedPriceHistory } from '../services/pricingUtils';
import { Course, Diploma, Workshop, PriceHistoryEntry } from '../types';
import DeleteModal from '../components/DeleteModal';
import * as XLSX from 'xlsx';

const Catalog: React.FC = () => {
  const { t, isRtl } = useTheme();
  const { effectiveProfile, hasPermission } = useAuth();
  const userProfile = effectiveProfile;
  const [activeTab, setActiveTab] = useState<'courses' | 'diplomas' | 'workshops'>('courses');
  const [courses, setCourses] = useState<Course[]>([]);
  const [diplomas, setDiplomas] = useState<Diploma[]>([]);
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [loading, setLoading] = useState(true);

  // Forms
  const [isModalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    basePrice: 0,
    effectiveFrom: new Date().toISOString().split('T')[0],
    priceChangeNote: '',
    active: true,
    courseIds: [] as string[],
    parentCourseId: '',
    usdPrice: 0,
    usdPriceAfterDiscount: 0,
    sarPrice: 0,
    eurPrice: 0
  });

  // Price History Modal
  const [historyModalProduct, setHistoryModalProduct] = useState<(Course | Diploma | Workshop) | null>(null);

  // Historical Price Audit & Enforcement Modal
  const [isAuditModalOpen, setAuditModalOpen] = useState(false);
  const [auditProductId, setAuditProductId] = useState<string>('all');
  const [auditCutoffDate, setAuditCutoffDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [auditHistoricalPrice, setAuditHistoricalPrice] = useState<number>(0);
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResults, setAuditResults] = useState<PriceAuditResult[] | null>(null);
  const [auditScannedCount, setAuditScannedCount] = useState<number>(0);
  const [auditAdjustedCount, setAuditAdjustedCount] = useState<number>(0);
  const [auditSuccessMessage, setAuditSuccessMessage] = useState<string>('');
  
  // Delete
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [deleteName, setDeleteName] = useState('');

  const canDelete = hasPermission('deleteRecords');

  const fetchData = async () => {
    setLoading(true);
    const [c, d] = await Promise.all([
      genericGet<Course>('catalog_courses'),
      genericGet<Diploma>('catalog_diplomas')
    ]);
    setCourses(c);
    setDiplomas(d);
    setLoading(false);

    // Workshops are fetched ISOLATED and on their own, never bundled into the
    // Promise.all above: a problem loading workshops must never be able to
    // take courses/diplomas down with it.
    try {
      const w = await genericGet<Workshop>('catalog_workshops');
      setWorkshops(w);
    } catch (err) {
      console.error('Failed to load workshops (non-fatal):', err);
      setWorkshops([]);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleExportCatalog = () => {
    const data = [
      ...courses.map(c => ({ 'Product Type': 'COURSE', 'Name': c.name, 'Price (EGP)': c.basePrice, 'Status': c.active ? 'Active' : 'Inactive' })),
      ...diplomas.map(d => ({ 'Product Type': 'DIPLOMA', 'Name': d.name, 'Price (EGP)': d.basePrice, 'Status': d.active ? 'Active' : 'Inactive' })),
      ...workshops.map(w => ({ 'Product Type': 'WORKSHOP', 'Name': w.name, 'Price (EGP)': w.basePrice, 'Status': w.active ? 'Active' : 'Inactive', 'Parent Course': courses.find(c => c.id === w.parentCourseId)?.name || '' }))
    ];
    
    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Price List");
    XLSX.writeFile(workbook, `SG_Catalog_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const collection = activeTab === 'courses' ? 'catalog_courses' : activeTab === 'diplomas' ? 'catalog_diplomas' : 'catalog_workshops';
    const performedBy = userProfile ? { name: userProfile.displayName, email: userProfile.email } : undefined;

    if (activeTab === 'workshops' && !formData.parentCourseId) {
      alert(isRtl ? 'من فضلك اختر الكورس الأساسي (الأب) لهذه الورشة' : 'Please select the parent course for this workshop');
      return;
    }

    const foreignPrices: Record<string, { price: number; priceAfterDiscount?: number }> = {};
    if (formData.usdPrice > 0) {
      foreignPrices['USD'] = {
        price: formData.usdPrice,
        priceAfterDiscount: formData.usdPriceAfterDiscount > 0 ? formData.usdPriceAfterDiscount : undefined
      };
    }
    if (formData.sarPrice > 0) {
      foreignPrices['SAR'] = { price: formData.sarPrice };
    }
    if (formData.eurPrice > 0) {
      foreignPrices['EUR'] = { price: formData.eurPrice };
    }

    const existingProduct = editingId
      ? (activeTab === 'courses' ? courses.find(c => c.id === editingId) : activeTab === 'diplomas' ? diplomas.find(d => d.id === editingId) : workshops.find(w => w.id === editingId))
      : undefined;

    const updatedPriceHistory = buildUpdatedPriceHistory(
      existingProduct,
      formData.basePrice,
      formData.effectiveFrom || new Date().toISOString().split('T')[0],
      Object.keys(foreignPrices).length > 0 ? foreignPrices : undefined,
      userProfile,
      formData.priceChangeNote
    );

    const payload: any = {
      name: formData.name,
      basePrice: formData.basePrice,
      active: formData.active,
      priceHistory: updatedPriceHistory,
      ...(activeTab === 'diplomas' ? { courseIds: formData.courseIds } : {}),
      ...(activeTab === 'workshops' ? { parentCourseId: formData.parentCourseId } : {}),
      foreignPrices: Object.keys(foreignPrices).length > 0 ? foreignPrices : undefined
    };

    if (editingId) {
      await genericUpdate(collection, editingId, payload, performedBy);
    } else {
      await genericAdd(collection, payload, performedBy);
    }
    setModalOpen(false);
    fetchData();
  };

  const handleDelete = async () => {
    if (deleteId) {
      const collection = activeTab === 'courses' ? 'catalog_courses' : activeTab === 'diplomas' ? 'catalog_diplomas' : 'catalog_workshops';
      const performedBy = userProfile ? { name: userProfile.displayName, email: userProfile.email } : undefined;
      await genericDelete(collection, deleteId, performedBy);
      setDeleteId(null);
      fetchData();
    }
  };

  const handleRunAudit = async (dryRun: boolean) => {
    setIsAuditing(true);
    setAuditSuccessMessage('');
    try {
      const res = await auditAndEnforceHistoricalBookingPrices({
        productId: auditProductId === 'all' ? undefined : auditProductId,
        cutoffDate: auditCutoffDate || undefined,
        historicalBasePrice: auditHistoricalPrice > 0 ? auditHistoricalPrice : undefined,
        dryRun,
        performedBy: userProfile ? { name: userProfile.displayName || 'Admin', email: userProfile.email || '', uid: (userProfile as any).uid } : undefined
      });

      setAuditResults(res.results);
      setAuditScannedCount(res.scannedCount);
      setAuditAdjustedCount(res.adjustedCount);

      if (!dryRun) {
        setAuditSuccessMessage(`تم بنجاح تثبيت وتصحيح الأسعار التاريخية لعدد ${res.adjustedCount} حجز سابق وإعادة ضبط المتبقي والأقساط!`);
      }
    } catch (err: any) {
      alert(`حدث خطأ أثناء فحص وتطبيق الأسعار: ${err?.message || err}`);
    } finally {
      setIsAuditing(false);
    }
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-2xl font-black">{t('catalog')}</h1>
          <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mt-1">Courses & Diplomas Pricing with Historical Rates Protection</p>
        </div>
        <div className="flex flex-wrap gap-3">
          {hasPermission('manageCatalog') && (
            <button
              onClick={() => {
                setAuditResults(null);
                setAuditSuccessMessage('');
                setAuditModalOpen(true);
              }}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold shadow-lg shadow-amber-600/20 transition-all text-xs flex items-center gap-2"
            >
              <i className="fas fa-shield-alt text-sm"></i>
              <span>{isRtl ? 'حماية وتدقيق أسعار الحجوزات السابقة' : 'Audit & Enforce Historical Prices'}</span>
            </button>
          )}

          {hasPermission('viewExports') && (
            <button 
              onClick={handleExportCatalog}
              className="px-5 py-2.5 bg-green-600 text-white rounded-xl font-bold shadow-lg hover:bg-green-700 transition-all text-xs uppercase flex items-center gap-2"
            >
              <i className="fas fa-file-excel"></i>
              Export Price List
            </button>
          )}
          {hasPermission('manageCatalog') && (
            <button
              onClick={() => {
                setEditingId(null);
                setFormData({
                  name: '',
                  basePrice: 0,
                  effectiveFrom: new Date().toISOString().split('T')[0],
                  priceChangeNote: '',
                  active: true,
                  courseIds: [],
                  parentCourseId: '',
                  usdPrice: 0,
                  usdPriceAfterDiscount: 0,
                  sarPrice: 0,
                  eurPrice: 0
                });
                setModalOpen(true);
              }}
              className="bg-primary-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-lg shadow-primary-500/30 transition-transform active:scale-95 text-xs flex items-center gap-2"
            >
              <i className="fas fa-plus"></i> {t('add')}
            </button>
          )}
        </div>
      </div>

      <div className="flex space-x-4 rtl:space-x-reverse mb-6 border-b dark:border-gray-700">
        <button
          onClick={() => setActiveTab('courses')}
          className={`pb-2 px-4 font-bold text-sm transition-colors ${activeTab === 'courses' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-500'}`}
        >
          {t('courses')} ({courses.length})
        </button>
        <button
          onClick={() => setActiveTab('diplomas')}
          className={`pb-2 px-4 font-bold text-sm transition-colors ${activeTab === 'diplomas' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-500'}`}
        >
          {t('diplomas')} ({diplomas.length})
        </button>
        <button
          onClick={() => setActiveTab('workshops')}
          className={`pb-2 px-4 font-bold text-sm transition-colors ${activeTab === 'workshops' ? 'text-primary-600 border-b-2 border-primary-600' : 'text-gray-500'}`}
        >
          {isRtl ? 'ورش العمل' : 'Workshops'} ({workshops.length})
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {activeTab === 'courses' ? (
          courses.map(course => (
            <div key={course.id} className="bg-white dark:bg-gray-800 p-7 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700 relative group overflow-hidden flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <span className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-full ${course.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {course.active ? t('active') : t('inactive')}
                  </span>
                  <div className="flex space-x-3 rtl:space-x-reverse opacity-0 group-hover:opacity-100 transition-opacity">
                    {hasPermission('manageCatalog') && (
                      <button 
                        onClick={() => {
                          setEditingId(course.id);
                          setFormData({
                            name: course.name,
                            basePrice: course.basePrice,
                            effectiveFrom: new Date().toISOString().split('T')[0],
                            priceChangeNote: '',
                            active: course.active,
                            courseIds: [],
                            parentCourseId: '',
                            usdPrice: course.foreignPrices?.USD?.price || 0,
                            usdPriceAfterDiscount: course.foreignPrices?.USD?.priceAfterDiscount || 0,
                            sarPrice: course.foreignPrices?.SAR?.price || 0,
                            eurPrice: course.foreignPrices?.EUR?.price || 0
                          });
                          setModalOpen(true);
                        }} 
                        className="text-blue-500 hover:text-blue-600 p-1"
                        title={t('edit')}
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                    )}
                    {hasPermission('deleteRecords') && (
                      <button 
                        onClick={() => { setDeleteId(course.id); setDeleteName(course.name); }} 
                        className="text-red-500 hover:text-red-600 p-1"
                        title={t('delete')}
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    )}
                  </div>
                </div>
                <h3 className="text-xl font-black mb-3 text-gray-900 dark:text-gray-100">{course.name}</h3>
              </div>

              <div className="mt-4 pt-4 border-t dark:border-gray-700 space-y-3">
                <div>
                  <div className="flex justify-between items-center">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Base Price (EGP)</p>
                    {course.priceHistory && course.priceHistory.length > 1 && (
                      <button
                        onClick={() => setHistoryModalProduct(course)}
                        className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                      >
                        <i className="fas fa-history text-[9px]"></i>
                        <span>سجل الأسعار ({course.priceHistory.length})</span>
                      </button>
                    )}
                  </div>
                  <p className="text-3xl font-black text-primary-600">{course.basePrice.toLocaleString()} <span className="text-xs">EGP</span></p>
                </div>
                
                {course.foreignPrices?.USD?.price && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800/40">
                    <span className="text-[10px] font-black text-blue-600 uppercase block mb-1">السعر الدولي (USD)</span>
                    <div className="flex items-center gap-2 font-black text-sm text-blue-900 dark:text-blue-200">
                      <span>${course.foreignPrices.USD.price} USD</span>
                      {course.foreignPrices.USD.priceAfterDiscount ? (
                        <span className="text-xs text-green-600 bg-green-100 dark:bg-green-900/40 px-2 py-0.5 rounded-md">
                          بعد الخصم: ${course.foreignPrices.USD.priceAfterDiscount}
                        </span>
                      ) : null}
                    </div>
                  </div>
                )}

                <div className="pt-2 flex justify-between items-center">
                  <button
                    onClick={() => {
                      setAuditProductId(course.id);
                      setAuditHistoricalPrice(0);
                      setAuditResults(null);
                      setAuditSuccessMessage('');
                      setAuditModalOpen(true);
                    }}
                    className="text-[11px] font-bold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1.5"
                  >
                    <i className="fas fa-user-shield text-[10px]"></i>
                    <span>تدقيق حجوزات هذا الكورس</span>
                  </button>

                  <button
                    onClick={() => setHistoryModalProduct(course)}
                    className="text-[11px] font-bold text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 flex items-center gap-1"
                  >
                    <i className="fas fa-history text-[10px]"></i>
                    <span>تاريخ الأسعار</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : activeTab === 'diplomas' ? (
          diplomas.map(diploma => (
            <div key={diploma.id} className="bg-white dark:bg-gray-800 p-7 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700 relative group overflow-hidden flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <span className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-full ${diploma.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {diploma.active ? t('active') : t('inactive')}
                  </span>
                  <div className="flex space-x-3 rtl:space-x-reverse opacity-0 group-hover:opacity-100 transition-opacity">
                    {hasPermission('manageCatalog') && (
                      <button 
                        onClick={() => {
                          setEditingId(diploma.id);
                          setFormData({
                            name: diploma.name,
                            basePrice: diploma.basePrice,
                            effectiveFrom: new Date().toISOString().split('T')[0],
                            priceChangeNote: '',
                            active: diploma.active,
                            courseIds: diploma.courseIds || [],
                            parentCourseId: '',
                            usdPrice: diploma.foreignPrices?.USD?.price || 0,
                            usdPriceAfterDiscount: diploma.foreignPrices?.USD?.priceAfterDiscount || 0,
                            sarPrice: diploma.foreignPrices?.SAR?.price || 0,
                            eurPrice: diploma.foreignPrices?.EUR?.price || 0
                          });
                          setModalOpen(true);
                        }} 
                        className="text-blue-500 hover:text-blue-600 p-1"
                        title={t('edit')}
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                    )}
                    {hasPermission('deleteRecords') && (
                      <button 
                        onClick={() => { setDeleteId(diploma.id); setDeleteName(diploma.name); }} 
                        className="text-red-500 hover:text-red-600 p-1"
                        title={t('delete')}
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    )}
                  </div>
                </div>
                <h3 className="text-xl font-black mb-1 text-gray-900 dark:text-gray-100">{diploma.name}</h3>
                <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mb-4">{diploma.courseIds?.length || 0} Unified Courses</p>
              </div>

              <div className="mt-4 pt-4 border-t dark:border-gray-700 space-y-3">
                <div>
                  <div className="flex justify-between items-center">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Diploma Price</p>
                    {diploma.priceHistory && diploma.priceHistory.length > 1 && (
                      <button
                        onClick={() => setHistoryModalProduct(diploma)}
                        className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                      >
                        <i className="fas fa-history text-[9px]"></i>
                        <span>سجل الأسعار ({diploma.priceHistory.length})</span>
                      </button>
                    )}
                  </div>
                  <p className="text-3xl font-black text-primary-600">{diploma.basePrice.toLocaleString()} <span className="text-xs">EGP</span></p>
                </div>

                {diploma.foreignPrices?.USD?.price && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800/40">
                    <span className="text-[10px] font-black text-blue-600 uppercase block mb-1">السعر الدولي (USD)</span>
                    <div className="flex items-center gap-2 font-black text-sm text-blue-900 dark:text-blue-200">
                      <span>${diploma.foreignPrices.USD.price} USD</span>
                      {diploma.foreignPrices.USD.priceAfterDiscount ? (
                        <span className="text-xs text-green-600 bg-green-100 dark:bg-green-900/40 px-2 py-0.5 rounded-md">
                          بعد الخصم: ${diploma.foreignPrices.USD.priceAfterDiscount}
                        </span>
                      ) : null}
                    </div>
                  </div>
                )}

                <div className="pt-2 flex justify-between items-center">
                  <button
                    onClick={() => {
                      setAuditProductId(diploma.id);
                      setAuditHistoricalPrice(0);
                      setAuditResults(null);
                      setAuditSuccessMessage('');
                      setAuditModalOpen(true);
                    }}
                    className="text-[11px] font-bold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1.5"
                  >
                    <i className="fas fa-user-shield text-[10px]"></i>
                    <span>تدقيق حجوزات هذه الدبلومة</span>
                  </button>

                  <button
                    onClick={() => setHistoryModalProduct(diploma)}
                    className="text-[11px] font-bold text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 flex items-center gap-1"
                  >
                    <i className="fas fa-history text-[10px]"></i>
                    <span>تاريخ الأسعار</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        ) : (
          workshops.map(workshop => (
            <div key={workshop.id} className="bg-white dark:bg-gray-800 p-7 rounded-[2rem] shadow-sm border border-gray-100 dark:border-gray-700 relative group overflow-hidden flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <span className={`px-3 py-1 text-[10px] font-black uppercase tracking-widest rounded-full ${workshop.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {workshop.active ? t('active') : t('inactive')}
                  </span>
                  <div className="flex space-x-3 rtl:space-x-reverse opacity-0 group-hover:opacity-100 transition-opacity">
                    {hasPermission('manageCatalog') && (
                      <button
                        onClick={() => {
                          setEditingId(workshop.id);
                          setFormData({
                            name: workshop.name,
                            basePrice: workshop.basePrice,
                            effectiveFrom: new Date().toISOString().split('T')[0],
                            priceChangeNote: '',
                            active: workshop.active,
                            courseIds: [],
                            parentCourseId: workshop.parentCourseId || '',
                            usdPrice: workshop.foreignPrices?.USD?.price || 0,
                            usdPriceAfterDiscount: workshop.foreignPrices?.USD?.priceAfterDiscount || 0,
                            sarPrice: workshop.foreignPrices?.SAR?.price || 0,
                            eurPrice: workshop.foreignPrices?.EUR?.price || 0
                          });
                          setModalOpen(true);
                        }}
                        className="text-blue-500 hover:text-blue-600 p-1"
                        title={t('edit')}
                      >
                        <i className="fas fa-edit"></i>
                      </button>
                    )}
                    {hasPermission('deleteRecords') && (
                      <button
                        onClick={() => { setDeleteId(workshop.id); setDeleteName(workshop.name); }}
                        className="text-red-500 hover:text-red-600 p-1"
                        title={t('delete')}
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    )}
                  </div>
                </div>
                <h3 className="text-xl font-black mb-1 text-gray-900 dark:text-gray-100">{workshop.name}</h3>
                <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mb-4">
                  {isRtl ? 'ورشة تابعة لكورس: ' : 'Sub-workshop of: '}
                  {courses.find(c => c.id === workshop.parentCourseId)?.name || (isRtl ? 'غير محدد' : 'Unassigned')}
                </p>
              </div>

              <div className="mt-4 pt-4 border-t dark:border-gray-700 space-y-3">
                <div>
                  <div className="flex justify-between items-center">
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Base Price (EGP)</p>
                    {workshop.priceHistory && workshop.priceHistory.length > 1 && (
                      <button
                        onClick={() => setHistoryModalProduct(workshop)}
                        className="text-[10px] font-black text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                      >
                        <i className="fas fa-history text-[9px]"></i>
                        <span>سجل الأسعار ({workshop.priceHistory.length})</span>
                      </button>
                    )}
                  </div>
                  <p className="text-3xl font-black text-primary-600">{workshop.basePrice.toLocaleString()} <span className="text-xs">EGP</span></p>
                </div>

                {workshop.foreignPrices?.USD?.price && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-100 dark:border-blue-800/40">
                    <span className="text-[10px] font-black text-blue-600 uppercase block mb-1">السعر الدولي (USD)</span>
                    <div className="flex items-center gap-2 font-black text-sm text-blue-900 dark:text-blue-200">
                      <span>${workshop.foreignPrices.USD.price} USD</span>
                      {workshop.foreignPrices.USD.priceAfterDiscount ? (
                        <span className="text-xs text-green-600 bg-green-100 dark:bg-green-900/40 px-2 py-0.5 rounded-md">
                          بعد الخصم: ${workshop.foreignPrices.USD.priceAfterDiscount}
                        </span>
                      ) : null}
                    </div>
                  </div>
                )}

                <div className="pt-2 flex justify-end items-center">
                  <button
                    onClick={() => setHistoryModalProduct(workshop)}
                    className="text-[11px] font-bold text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 flex items-center gap-1"
                  >
                    <i className="fas fa-history text-[10px]"></i>
                    <span>تاريخ الأسعار</span>
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2rem] shadow-2xl w-full max-w-lg my-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-black uppercase tracking-tight">{editingId ? t('edit') : t('add')} Record</h2>
              <button onClick={() => setModalOpen(false)} className="text-gray-400 hover:text-gray-600"><i className="fas fa-times text-lg"></i></button>
            </div>
            
            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t('name')}</label>
                <input type="text" required value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none font-bold" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">{t('basePrice')} (ج.م EGP)</label>
                  <input type="number" required value={formData.basePrice} onChange={e => setFormData({ ...formData, basePrice: parseFloat(e.target.value) || 0 })} className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none font-black" />
                </div>
                <div>
                  <label className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-1 block">تاريخ سريان السعر الجديد</label>
                  <input type="date" required value={formData.effectiveFrom} onChange={e => setFormData({ ...formData, effectiveFrom: e.target.value })} className="w-full p-3 bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-xl outline-none font-bold text-xs" />
                </div>
              </div>

              {/* Informational Box about Historical Pricing */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 rounded-xl text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-black text-amber-800 dark:text-amber-300">
                  <i className="fas fa-shield-alt"></i>
                  <span>قاعدة تثبيت الأسعار للحجوزات السابقة</span>
                </div>
                <p className="text-amber-900/80 dark:text-amber-200/80 text-[11px] leading-relaxed">
                  السعر الجديد سيتم تطبيقه فقط على الحجوزات المسجلة بتاريخ {formData.effectiveFrom} أو ما بعده. جميع الحجوزات السابقة ستظل محتفظة بالأسعار التاريخية المعتمدة تلقائياً دون أي تأثير على أقساطهم.
                </p>
              </div>

              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1 block">ملاحظة / سبب تعديل السعر (اختياري)</label>
                <input 
                  type="text" 
                  placeholder="مثال: زيادة السعر للربع الثالث" 
                  value={formData.priceChangeNote} 
                  onChange={e => setFormData({ ...formData, priceChangeNote: e.target.value })} 
                  className="w-full p-2.5 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none font-semibold text-xs" 
                />
              </div>

              {/* Foreign Currency Pricing Options */}
              <div className="p-4 bg-gray-50 dark:bg-gray-700/40 rounded-2xl border dark:border-gray-700 space-y-3">
                <div className="flex items-center gap-2 text-xs font-black text-blue-600 dark:text-blue-400">
                  <i className="fas fa-globe"></i>
                  <span>تسعير العملات الأجنبية (اختياري - للتحويل من الخارج)</span>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">السعر بالدولار ($ USD)</label>
                    <input
                      type="number"
                      placeholder="مثال: 100"
                      value={formData.usdPrice || ''}
                      onChange={e => setFormData({ ...formData, usdPrice: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">السعر بالدولار بعد الخصم ($)</label>
                    <input
                      type="number"
                      placeholder="مثال: 80"
                      value={formData.usdPriceAfterDiscount || ''}
                      onChange={e => setFormData({ ...formData, usdPriceAfterDiscount: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">السعر بالريال السعودي (ر.س SAR)</label>
                    <input
                      type="number"
                      placeholder="اختياري"
                      value={formData.sarPrice || ''}
                      onChange={e => setFormData({ ...formData, sarPrice: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-gray-500 block mb-1">السعر باليورو (€ EUR)</label>
                    <input
                      type="number"
                      placeholder="اختياري"
                      value={formData.eurPrice || ''}
                      onChange={e => setFormData({ ...formData, eurPrice: parseFloat(e.target.value) || 0 })}
                      className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs"
                    />
                  </div>
                </div>
              </div>

              {activeTab === 'diplomas' && (
                <div>
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">Included Courses</label>
                   <select multiple className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl h-32 font-medium" value={formData.courseIds} onChange={e => setFormData({ ...formData, courseIds: Array.from(e.target.selectedOptions).map(o => (o as HTMLOptionElement).value) })}>
                    {courses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                   </select>
                </div>
              )}

              {activeTab === 'workshops' && (
                <div>
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1 block">
                     {isRtl ? 'الكورس الأساسي (الأب)' : 'Parent Course'}
                   </label>
                   <select required value={formData.parentCourseId} onChange={e => setFormData({ ...formData, parentCourseId: e.target.value })} className="w-full p-3 bg-gray-50 dark:bg-gray-700 rounded-xl outline-none font-bold">
                     <option value="">{isRtl ? '-- اختر الكورس --' : '-- Select Course --'}</option>
                     {courses.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                   </select>
                   <p className="text-[10px] text-gray-400 mt-1.5 leading-relaxed">
                     {isRtl
                       ? 'حجز هذه الورشة سيسجل العميل في إحدى مجموعات هذا الكورس الموجودة بالفعل — الورش لا تملك مجموعات خاصة بها.'
                       : "Booking this workshop will assign the customer to one of this course's existing groups — workshops don't have their own groups."}
                   </p>
                </div>
              )}
              <label className="flex items-center space-x-3 rtl:space-x-reverse bg-gray-50 dark:bg-gray-700/50 p-4 rounded-xl cursor-pointer"><input type="checkbox" checked={formData.active} onChange={e => setFormData({ ...formData, active: e.target.checked })} /><span className="text-sm font-bold">Product is available for booking</span></label>
              <div className="flex justify-end gap-3 pt-6 border-t dark:border-gray-700">
                <button type="button" onClick={() => setModalOpen(false)} className="px-6 py-2 font-bold text-gray-400 uppercase text-xs">Cancel</button>
                <button type="submit" className="px-10 py-3 bg-primary-600 text-white rounded-xl font-black shadow-lg shadow-primary-500/30">Save Product</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Price History Modal */}
      {historyModalProduct && (
        <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2rem] shadow-2xl w-full max-w-xl my-8 space-y-6">
            <div className="flex justify-between items-center border-b dark:border-gray-700 pb-4">
              <div>
                <h3 className="text-xl font-black text-gray-900 dark:text-gray-100 flex items-center gap-2">
                  <i className="fas fa-history text-indigo-600"></i>
                  <span>سجل الأسعار التاريخية</span>
                </h3>
                <p className="text-xs font-bold text-gray-500 mt-1">{historyModalProduct.name}</p>
              </div>
              <button 
                onClick={() => setHistoryModalProduct(null)}
                className="w-9 h-9 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 hover:bg-gray-200"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="space-y-3 max-h-[60vh] overflow-y-auto custom-scrollbar pr-1">
              {historyModalProduct.priceHistory && historyModalProduct.priceHistory.length > 0 ? (
                historyModalProduct.priceHistory.map((entry, idx) => (
                  <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-700/40 rounded-2xl border dark:border-gray-700 flex flex-col md:flex-row md:justify-between md:items-center gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-black px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300">
                          {entry.effectiveTo ? `${entry.effectiveFrom} إلى ${entry.effectiveTo}` : `من ${entry.effectiveFrom} حتى الآن (الحالي)`}
                        </span>
                        {!entry.effectiveTo && (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-green-100 text-green-700">
                            نشط
                          </span>
                        )}
                      </div>
                      {entry.note && (
                        <p className="text-xs text-gray-600 dark:text-gray-300 font-semibold">{entry.note}</p>
                      )}
                      <p className="text-[10px] text-gray-400">
                        تم التعديل بواسطة: <span className="font-bold">{entry.changedBy || 'Admin'}</span> في {entry.changedAt ? new Date(entry.changedAt).toLocaleDateString('ar-EG') : '-'}
                      </p>
                    </div>
                    <div className="text-right rtl:text-left">
                      <div className="text-2xl font-black text-primary-600">{entry.price.toLocaleString()} <span className="text-xs">ج.م</span></div>
                      {entry.foreignPrices?.USD?.price && (
                        <div className="text-xs font-bold text-blue-600">${entry.foreignPrices.USD.price} USD</div>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-6 text-center text-gray-400 bg-gray-50 dark:bg-gray-700/20 rounded-2xl">
                  <i className="fas fa-info-circle text-2xl mb-2 text-gray-300"></i>
                  <p className="text-xs font-bold">لا يوجد سجل تعديلات سابقة لهذا الكورس. السعر الأساسي الحالي هو {historyModalProduct.basePrice.toLocaleString()} ج.م.</p>
                </div>
              )}
            </div>

            <div className="flex justify-end pt-2 border-t dark:border-gray-700">
              <button
                onClick={() => setHistoryModalProduct(null)}
                className="px-6 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-xl text-xs font-black"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Historical Price Audit & Fix Modal */}
      {isAuditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-[2.5rem] shadow-2xl w-full max-w-3xl my-8 space-y-6 animate-in fade-in-50">
            <div className="flex justify-between items-start border-b dark:border-gray-700 pb-4">
              <div>
                <h2 className="text-xl font-black text-gray-900 dark:text-gray-100 flex items-center gap-2.5">
                  <span className="w-9 h-9 rounded-2xl bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 flex items-center justify-center text-base">
                    <i className="fas fa-user-shield"></i>
                  </span>
                  <span>تدقيق وضمان تطبيق الأسعار القديمة للحجوزات السابقة</span>
                </h2>
                <p className="text-xs text-gray-500 font-semibold mt-1">
                  فحص الحجوزات المسجلة قبل تعديل الأسعار للتأكد من محاسبتهم بالسعر القديم وتصحيح المتبقي والأقساط
                </p>
              </div>
              <button 
                onClick={() => setAuditModalOpen(false)}
                className="w-9 h-9 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-gray-500 hover:bg-gray-200"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            {/* Audit Configuration Filter */}
            <div className="p-5 bg-gray-50 dark:bg-gray-700/40 rounded-2xl border dark:border-gray-700 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-gray-500 block mb-1">الكورس / الدبلومة</label>
                  <select 
                    value={auditProductId} 
                    onChange={e => setAuditProductId(e.target.value)}
                    className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs border dark:border-gray-600"
                  >
                    <option value="all">جميع الكورسات والدبلومات</option>
                    <optgroup label="الكورسات">
                      {courses.map(c => <option key={c.id} value={c.id}>{c.name} (السعر الحالي: {c.basePrice} ج.م)</option>)}
                    </optgroup>
                    <optgroup label="الدبلومات">
                      {diplomas.map(d => <option key={d.id} value={d.id}>{d.name} (السعر الحالي: {d.basePrice} ج.م)</option>)}
                    </optgroup>
                    {workshops.length > 0 && (
                      <optgroup label="ورش العمل">
                        {workshops.map(w => <option key={w.id} value={w.id}>{w.name} (السعر الحالي: {w.basePrice} ج.م)</option>)}
                      </optgroup>
                    )}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-gray-500 block mb-1">تاريخ تغيير السعر (Cutoff Date)</label>
                  <input 
                    type="date"
                    value={auditCutoffDate}
                    onChange={e => setAuditCutoffDate(e.target.value)}
                    className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs border dark:border-gray-600"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black uppercase tracking-wider text-gray-500 block mb-1">السعر التاريخي المطلوب تطبيقه (ج.م)</label>
                  <input 
                    type="number"
                    placeholder="مثال: 4000 (أو 0 للتلقائي)"
                    value={auditHistoricalPrice || ''}
                    onChange={e => setAuditHistoricalPrice(parseFloat(e.target.value) || 0)}
                    className="w-full p-2.5 bg-white dark:bg-gray-800 rounded-xl outline-none font-bold text-xs border dark:border-gray-600"
                  />
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                <p className="text-[11px] text-gray-500 font-semibold">
                  💡 سيتم فحص أي حجز تم تسجيله قبل تاريخ <span className="font-bold text-primary-600">{auditCutoffDate}</span> والتأكد من مطابقة سعره الأساسي للسعر القديم.
                </p>

                <div className="flex gap-2">
                  <button
                    onClick={() => handleRunAudit(true)}
                    disabled={isAuditing}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all disabled:opacity-50"
                  >
                    {isAuditing ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-search"></i>}
                    <span>فحص ومعاينة الحجوزات المتأثرة (Dry Run)</span>
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm(isRtl ? 'هل تريد بالتأكيد تطبيق وتصحيح الأسعار التاريخية على هذه الحجوزات وتحديث الأقساط والمتبقي؟' : 'Are you sure you want to enforce historical prices and recalculate remaining/installments?')) {
                        handleRunAudit(false);
                      }
                    }}
                    disabled={isAuditing}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 transition-all disabled:opacity-50 shadow-md shadow-emerald-600/20"
                  >
                    {isAuditing ? <i className="fas fa-spinner fa-spin"></i> : <i className="fas fa-check-double"></i>}
                    <span>تطبيق وتصحيح الحجوزات فوراً</span>
                  </button>
                </div>
              </div>
            </div>

            {auditSuccessMessage && (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl flex items-center gap-3 text-emerald-800 dark:text-emerald-200 text-xs font-black animate-in fade-in">
                <i className="fas fa-check-circle text-lg text-emerald-500"></i>
                <span>{auditSuccessMessage}</span>
              </div>
            )}

            {/* Results Table */}
            {auditResults && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black uppercase tracking-wider text-gray-600 dark:text-gray-400">
                    نتائج الفحص: {auditResults.length} حجز بحاجة لتطبيق السعر القديم (من إجمالي {auditScannedCount} حجز تم فحصه)
                  </h4>
                  {auditAdjustedCount > 0 && (
                    <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                      تم تصحيح {auditAdjustedCount} حجز
                    </span>
                  )}
                </div>

                {auditResults.length > 0 ? (
                  <div className="max-h-[35vh] overflow-y-auto custom-scrollbar border dark:border-gray-700 rounded-2xl">
                    <table className="w-full text-right rtl:text-right text-xs">
                      <thead className="bg-gray-100 dark:bg-gray-700/80 sticky top-0 text-[10px] font-black text-gray-500 uppercase">
                        <tr>
                          <th className="p-3">العميل</th>
                          <th className="p-3">الكورس</th>
                          <th className="p-3">تاريخ الحجز</th>
                          <th className="p-3">السعر الحالي المسجل</th>
                          <th className="p-3">السعر التاريخي المصحح</th>
                          <th className="p-3">المتبقي القديم</th>
                          <th className="p-3">المتبقي الجديد</th>
                          <th className="p-3">الأقساط</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y dark:divide-gray-700 bg-white dark:bg-gray-800 font-semibold">
                        {auditResults.map((r, idx) => (
                          <tr key={idx} className="hover:bg-gray-50 dark:hover:bg-gray-700/50">
                            <td className="p-3 font-bold text-gray-900 dark:text-gray-100">{r.customerName}</td>
                            <td className="p-3 text-gray-600 dark:text-gray-300">{r.productName}</td>
                            <td className="p-3 text-gray-500 font-mono text-[11px]">{r.bookingDate}</td>
                            <td className="p-3 text-red-600 font-bold line-through">{r.oldBasePriceSnapshot.toLocaleString()} ج.م</td>
                            <td className="p-3 text-emerald-600 font-black">{r.newCorrectBasePrice.toLocaleString()} ج.م</td>
                            <td className="p-3 text-gray-500">{r.oldRemaining.toLocaleString()} ج.م</td>
                            <td className="p-3 text-primary-600 font-bold">{r.newRemaining.toLocaleString()} ج.م</td>
                            <td className="p-3">
                              {r.installmentsAdjusted ? (
                                <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-black">
                                  تم إعادة ضبطها
                                </span>
                              ) : (
                                <span className="text-[10px] text-gray-400">
                                  جاهزة للضبط
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="p-6 text-center text-gray-500 bg-gray-50 dark:bg-gray-700/20 rounded-2xl text-xs font-bold">
                    <i className="fas fa-check-circle text-2xl text-green-500 mb-2 block"></i>
                    جميع الحجوزات السابقة مطابقة للأسعار التاريخية المعتمدة ولا توجد أي حجوزات متأثرة بالسعر الجديد!
                  </div>
                )}
              </div>
            )}

            <div className="flex justify-end pt-3 border-t dark:border-gray-700">
              <button
                onClick={() => setAuditModalOpen(false)}
                className="px-6 py-2.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-xl text-xs font-black"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

      <DeleteModal isOpen={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} itemName={deleteName} />
    </div>
  );
};

export default Catalog;
